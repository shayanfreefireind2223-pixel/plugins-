package io.csky;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.stream.Collectors;
import java.util.zip.GZIPOutputStream;
import javax.net.ssl.HttpsURLConnection;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public class a {
   private final Plugin a;
   private final io.csky.a.f b;

   public a(JavaPlugin plugin, int serviceId) {
      this.a = plugin;
      File bStatsFolder = new File(plugin.getDataFolder().getParentFile(), "bStats");
      File configFile = new File(bStatsFolder, "config.yml");
      YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
      if (!config.isSet("serverUuid")) {
         config.addDefault("enabled", true);
         config.addDefault("serverUuid", UUID.randomUUID().toString());
         config.addDefault("logFailedRequests", false);
         config.addDefault("logSentData", false);
         config.addDefault("logResponseStatusText", false);
         config.options().header("bStats (https://bStats.org) collects some basic information for plugin authors, like how\nmany people use their plugin and their total player count. It's recommended to keep bStats\nenabled, but if you're not comfortable with this, you can turn this setting off. There is no\nperformance penalty associated with having metrics enabled, and data sent to bStats is fully\nanonymous.").copyDefaults(true);

         try {
            config.save(configFile);
         } catch (IOException var11) {
         }
      }

      boolean enabled = config.getBoolean("enabled", true);
      String serverUUID = config.getString("serverUuid");
      boolean logErrors = config.getBoolean("logFailedRequests", false);
      boolean logSentData = config.getBoolean("logSentData", false);
      boolean logResponseStatusText = config.getBoolean("logResponseStatusText", false);
      Consumer var10007 = this::a;
      Consumer var10008 = this::b;
      Consumer var10009 = (submitDataTask) -> {
         Bukkit.getScheduler().runTask(plugin, submitDataTask);
      };
      Objects.requireNonNull(plugin);
      this.b = new io.csky.a.f("bukkit", serverUUID, serviceId, enabled, var10007, var10008, var10009, plugin::isEnabled, (message, error) -> {
         this.a.getLogger().log(Level.WARNING, message, error);
      }, (message) -> {
         this.a.getLogger().log(Level.INFO, message);
      }, logErrors, logSentData, logResponseStatusText);
   }

   public void a() {
      this.b.a();
   }

   public void a(io.csky.a.c chart) {
      this.b.a(chart);
   }

   private void a(io.csky.a.e builder) {
      builder.a("playerAmount", this.b());
      builder.a("onlineMode", Bukkit.getOnlineMode() ? 1 : 0);
      builder.a("bukkitVersion", Bukkit.getVersion());
      builder.a("bukkitName", Bukkit.getName());
      builder.a("javaVersion", System.getProperty("java.version"));
      builder.a("osName", System.getProperty("os.name"));
      builder.a("osArch", System.getProperty("os.arch"));
      builder.a("osVersion", System.getProperty("os.version"));
      builder.a("coreCount", Runtime.getRuntime().availableProcessors());
   }

   private void b(io.csky.a.e builder) {
      builder.a("pluginVersion", this.a.getDescription().getVersion());
   }

   private int b() {
      try {
         Method onlinePlayersMethod = Class.forName("org.bukkit.Server").getMethod("getOnlinePlayers");
         return onlinePlayersMethod.getReturnType().equals(Collection.class) ? ((Collection)onlinePlayersMethod.invoke(Bukkit.getServer())).size() : ((Player[])onlinePlayersMethod.invoke(Bukkit.getServer())).length;
      } catch (Exception var2) {
         return Bukkit.getOnlinePlayers().size();
      }
   }

   public static class f {
      public static final String a = "3.0.2";
      private static final String b = "https://bStats.org/api/v2/data/%s";
      private final ScheduledExecutorService c;
      private final String d;
      private final String e;
      private final int f;
      private final Consumer<io.csky.a.e> g;
      private final Consumer<io.csky.a.e> h;
      private final Consumer<Runnable> i;
      private final Supplier<Boolean> j;
      private final BiConsumer<String, Throwable> k;
      private final Consumer<String> l;
      private final boolean m;
      private final boolean n;
      private final boolean o;
      private final Set<io.csky.a.c> p = new HashSet();
      private final boolean q;

      public f(String platform, String serverUuid, int serviceId, boolean enabled, Consumer<io.csky.a.e> appendPlatformDataConsumer, Consumer<io.csky.a.e> appendServiceDataConsumer, Consumer<Runnable> submitTaskConsumer, Supplier<Boolean> checkServiceEnabledSupplier, BiConsumer<String, Throwable> errorLogger, Consumer<String> infoLogger, boolean logErrors, boolean logSentData, boolean logResponseStatusText) {
         ScheduledThreadPoolExecutor scheduler = new ScheduledThreadPoolExecutor(1, (task) -> {
            return new Thread(task, "bStats-Metrics");
         });
         scheduler.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
         this.c = scheduler;
         this.d = platform;
         this.e = serverUuid;
         this.f = serviceId;
         this.q = enabled;
         this.g = appendPlatformDataConsumer;
         this.h = appendServiceDataConsumer;
         this.i = submitTaskConsumer;
         this.j = checkServiceEnabledSupplier;
         this.k = errorLogger;
         this.l = infoLogger;
         this.m = logErrors;
         this.n = logSentData;
         this.o = logResponseStatusText;
         this.d();
         if (enabled) {
            this.b();
         }

      }

      public void a(io.csky.a.c chart) {
         this.p.add(chart);
      }

      public void a() {
         this.c.shutdown();
      }

      private void b() {
         Runnable submitTask = () -> {
            if (this.q && (Boolean)this.j.get()) {
               if (this.i != null) {
                  this.i.accept(this::c);
               } else {
                  this.c();
               }

            } else {
               this.c.shutdown();
            }
         };
         long initialDelay = (long)(60000.0D * (3.0D + Math.random() * 3.0D));
         long secondDelay = (long)(60000.0D * Math.random() * 30.0D);
         this.c.schedule(submitTask, initialDelay, TimeUnit.MILLISECONDS);
         this.c.scheduleAtFixedRate(submitTask, initialDelay + secondDelay, 1800000L, TimeUnit.MILLISECONDS);
      }

      private void c() {
         io.csky.a.e baseJsonBuilder = new io.csky.a.e();
         this.g.accept(baseJsonBuilder);
         io.csky.a.e serviceJsonBuilder = new io.csky.a.e();
         this.h.accept(serviceJsonBuilder);
         io.csky.a.e.a[] chartData = (io.csky.a.e.a[])this.p.stream().map((customChart) -> {
            return customChart.a(this.k, this.m);
         }).filter(Objects::nonNull).toArray((x$0) -> {
            return new io.csky.a.e.a[x$0];
         });
         serviceJsonBuilder.a("id", this.f);
         serviceJsonBuilder.a("customCharts", chartData);
         baseJsonBuilder.a("service", serviceJsonBuilder.a());
         baseJsonBuilder.a("serverUUID", this.e);
         baseJsonBuilder.a("metricsVersion", "3.0.2");
         io.csky.a.e.a data = baseJsonBuilder.a();
         this.c.execute(() -> {
            try {
               this.a(data);
            } catch (Exception var3) {
               if (this.m) {
                  this.k.accept("Could not submit bStats metrics data", var3);
               }
            }

         });
      }

      private void a(io.csky.a.e.a data) {
         if (this.n) {
            this.l.accept("Sent bStats metrics data: " + data.toString());
         }

         String url = String.format("https://bStats.org/api/v2/data/%s", this.d);
         HttpsURLConnection connection = (HttpsURLConnection)(new URL(url)).openConnection();
         byte[] compressedData = a(data.toString());
         connection.setRequestMethod("POST");
         connection.addRequestProperty("Accept", "application/json");
         connection.addRequestProperty("Connection", "close");
         connection.addRequestProperty("Content-Encoding", "gzip");
         connection.addRequestProperty("Content-Length", String.valueOf(compressedData.length));
         connection.setRequestProperty("Content-Type", "application/json");
         connection.setRequestProperty("User-Agent", "Metrics-Service/1");
         connection.setDoOutput(true);
         DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());

         try {
            outputStream.write(compressedData);
         } catch (Throwable var11) {
            try {
               outputStream.close();
            } catch (Throwable var9) {
               var11.addSuppressed(var9);
            }

            throw var11;
         }

         outputStream.close();
         StringBuilder builder = new StringBuilder();
         BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));

         String line;
         try {
            while((line = bufferedReader.readLine()) != null) {
               builder.append(line);
            }
         } catch (Throwable var12) {
            try {
               bufferedReader.close();
            } catch (Throwable var10) {
               var12.addSuppressed(var10);
            }

            throw var12;
         }

         bufferedReader.close();
         if (this.o) {
            this.l.accept("Sent data to bStats and received response: " + String.valueOf(builder));
         }

      }

      private void d() {
         if (System.getProperty("bstats.relocatecheck") == null || !System.getProperty("bstats.relocatecheck").equals("false")) {
            String defaultPackage = new String(new byte[]{111, 114, 103, 46, 98, 115, 116, 97, 116, 115});
            String examplePackage = new String(new byte[]{121, 111, 117, 114, 46, 112, 97, 99, 107, 97, 103, 101});
            if (io.csky.a.f.class.getPackage().getName().startsWith(defaultPackage) || io.csky.a.f.class.getPackage().getName().startsWith(examplePackage)) {
               throw new IllegalStateException("bStats Metrics class has not been relocated correctly!");
            }
         }

      }

      private static byte[] a(String str) {
         if (str == null) {
            return null;
         } else {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            GZIPOutputStream gzip = new GZIPOutputStream(outputStream);

            try {
               gzip.write(str.getBytes(StandardCharsets.UTF_8));
            } catch (Throwable var6) {
               try {
                  gzip.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }

               throw var6;
            }

            gzip.close();
            return outputStream.toByteArray();
         }
      }
   }

   public abstract static class c {
      private final String a;

      protected c(String chartId) {
         if (chartId == null) {
            throw new IllegalArgumentException("chartId must not be null");
         } else {
            this.a = chartId;
         }
      }

      public io.csky.a.e.a a(BiConsumer<String, Throwable> errorLogger, boolean logErrors) {
         io.csky.a.e builder = new io.csky.a.e();
         builder.a("chartId", this.a);

         try {
            io.csky.a.e.a data = this.a();
            if (data == null) {
               return null;
            }

            builder.a("data", data);
         } catch (Throwable var5) {
            if (logErrors) {
               errorLogger.accept("Failed to get data for custom chart with id " + this.a, var5);
            }

            return null;
         }

         return builder.a();
      }

      protected abstract io.csky.a.e.a a();
   }

   public static class e {
      private StringBuilder a = new StringBuilder();
      private boolean b = false;

      public e() {
         this.a.append("{");
      }

      public io.csky.a.e a(String key) {
         this.b(key, "null");
         return this;
      }

      public io.csky.a.e a(String key, String value) {
         if (value == null) {
            throw new IllegalArgumentException("JSON value must not be null");
         } else {
            this.b(key, "\"" + b(value) + "\"");
            return this;
         }
      }

      public io.csky.a.e a(String key, int value) {
         this.b(key, String.valueOf(value));
         return this;
      }

      public io.csky.a.e a(String key, io.csky.a.e.a object) {
         if (object == null) {
            throw new IllegalArgumentException("JSON object must not be null");
         } else {
            this.b(key, object.toString());
            return this;
         }
      }

      public io.csky.a.e a(String key, String[] values) {
         if (values == null) {
            throw new IllegalArgumentException("JSON values must not be null");
         } else {
            String escapedValues = (String)Arrays.stream(values).map((value) -> {
               return "\"" + b(value) + "\"";
            }).collect(Collectors.joining(","));
            this.b(key, "[" + escapedValues + "]");
            return this;
         }
      }

      public io.csky.a.e a(String key, int[] values) {
         if (values == null) {
            throw new IllegalArgumentException("JSON values must not be null");
         } else {
            String escapedValues = (String)Arrays.stream(values).mapToObj(String::valueOf).collect(Collectors.joining(","));
            this.b(key, "[" + escapedValues + "]");
            return this;
         }
      }

      public io.csky.a.e a(String key, io.csky.a.e.a[] values) {
         if (values == null) {
            throw new IllegalArgumentException("JSON values must not be null");
         } else {
            String escapedValues = (String)Arrays.stream(values).map(io.csky.a.e.a::toString).collect(Collectors.joining(","));
            this.b(key, "[" + escapedValues + "]");
            return this;
         }
      }

      private void b(String key, String escapedValue) {
         if (this.a == null) {
            throw new IllegalStateException("JSON has already been built");
         } else if (key == null) {
            throw new IllegalArgumentException("JSON key must not be null");
         } else {
            if (this.b) {
               this.a.append(",");
            }

            this.a.append("\"").append(b(key)).append("\":").append(escapedValue);
            this.b = true;
         }
      }

      public io.csky.a.e.a a() {
         if (this.a == null) {
            throw new IllegalStateException("JSON has already been built");
         } else {
            io.csky.a.e.a object = new io.csky.a.e.a(this.a.append("}").toString());
            this.a = null;
            return object;
         }
      }

      private static String b(String value) {
         StringBuilder builder = new StringBuilder();

         for(int i = 0; i < value.length(); ++i) {
            char c = value.charAt(i);
            if (c == '"') {
               builder.append("\\\"");
            } else if (c == '\\') {
               builder.append("\\\\");
            } else if (c <= 15) {
               builder.append("\\u000").append(Integer.toHexString(c));
            } else if (c <= 31) {
               builder.append("\\u00").append(Integer.toHexString(c));
            } else {
               builder.append(c);
            }
         }

         return builder.toString();
      }

      public static class a {
         private final String a;

         private a(String value) {
            this.a = value;
         }

         public String toString() {
            return this.a;
         }
      }
   }

   public static class j extends io.csky.a.c {
      private final Callable<Integer> a;

      public j(String chartId, Callable<Integer> callable) {
         super(chartId);
         this.a = callable;
      }

      protected io.csky.a.e.a a() {
         int value = (Integer)this.a.call();
         return value == 0 ? null : (new io.csky.a.e()).a("value", value).a();
      }
   }

   public static class d extends io.csky.a.c {
      private final Callable<Map<String, Map<String, Integer>>> a;

      public d(String chartId, Callable<Map<String, Map<String, Integer>>> callable) {
         super(chartId);
         this.a = callable;
      }

      public io.csky.a.e.a a() {
         io.csky.a.e valuesBuilder = new io.csky.a.e();
         Map map = (Map)this.a.call();
         if (map != null && !map.isEmpty()) {
            boolean reallyAllSkipped = true;
            Iterator var4 = map.entrySet().iterator();

            while(var4.hasNext()) {
               Entry entryValues = (Entry)var4.next();
               io.csky.a.e valueBuilder = new io.csky.a.e();
               boolean allSkipped = true;

               for(Iterator var8 = ((Map)map.get(entryValues.getKey())).entrySet().iterator(); var8.hasNext(); allSkipped = false) {
                  Entry valueEntry = (Entry)var8.next();
                  valueBuilder.a((String)valueEntry.getKey(), (Integer)valueEntry.getValue());
               }

               if (!allSkipped) {
                  reallyAllSkipped = false;
                  valuesBuilder.a((String)entryValues.getKey(), valueBuilder.a());
               }
            }

            if (reallyAllSkipped) {
               return null;
            } else {
               return (new io.csky.a.e()).a("values", valuesBuilder.a()).a();
            }
         } else {
            return null;
         }
      }
   }

   public static class a extends io.csky.a.c {
      private final Callable<Map<String, int[]>> a;

      public a(String chartId, Callable<Map<String, int[]>> callable) {
         super(chartId);
         this.a = callable;
      }

      protected io.csky.a.e.a a() {
         io.csky.a.e valuesBuilder = new io.csky.a.e();
         Map map = (Map)this.a.call();
         if (map != null && !map.isEmpty()) {
            boolean allSkipped = true;
            Iterator var4 = map.entrySet().iterator();

            while(var4.hasNext()) {
               Entry entry = (Entry)var4.next();
               if (((int[])entry.getValue()).length != 0) {
                  allSkipped = false;
                  valuesBuilder.a((String)entry.getKey(), (int[])entry.getValue());
               }
            }

            if (allSkipped) {
               return null;
            } else {
               return (new io.csky.a.e()).a("values", valuesBuilder.a()).a();
            }
         } else {
            return null;
         }
      }
   }

   public static class h extends io.csky.a.c {
      private final Callable<Map<String, Integer>> a;

      public h(String chartId, Callable<Map<String, Integer>> callable) {
         super(chartId);
         this.a = callable;
      }

      protected io.csky.a.e.a a() {
         io.csky.a.e valuesBuilder = new io.csky.a.e();
         Map map = (Map)this.a.call();
         if (map != null && !map.isEmpty()) {
            Iterator var3 = map.entrySet().iterator();

            while(var3.hasNext()) {
               Entry entry = (Entry)var3.next();
               valuesBuilder.a((String)entry.getKey(), new int[]{(Integer)entry.getValue()});
            }

            return (new io.csky.a.e()).a("values", valuesBuilder.a()).a();
         } else {
            return null;
         }
      }
   }

   public static class b extends io.csky.a.c {
      private final Callable<Map<String, Integer>> a;

      public b(String chartId, Callable<Map<String, Integer>> callable) {
         super(chartId);
         this.a = callable;
      }

      protected io.csky.a.e.a a() {
         io.csky.a.e valuesBuilder = new io.csky.a.e();
         Map map = (Map)this.a.call();
         if (map != null && !map.isEmpty()) {
            boolean allSkipped = true;
            Iterator var4 = map.entrySet().iterator();

            while(var4.hasNext()) {
               Entry entry = (Entry)var4.next();
               if ((Integer)entry.getValue() != 0) {
                  allSkipped = false;
                  valuesBuilder.a((String)entry.getKey(), (Integer)entry.getValue());
               }
            }

            if (allSkipped) {
               return null;
            } else {
               return (new io.csky.a.e()).a("values", valuesBuilder.a()).a();
            }
         } else {
            return null;
         }
      }
   }

   public static class g extends io.csky.a.c {
      private final Callable<Map<String, Integer>> a;

      public g(String chartId, Callable<Map<String, Integer>> callable) {
         super(chartId);
         this.a = callable;
      }

      protected io.csky.a.e.a a() {
         io.csky.a.e valuesBuilder = new io.csky.a.e();
         Map map = (Map)this.a.call();
         if (map != null && !map.isEmpty()) {
            boolean allSkipped = true;
            Iterator var4 = map.entrySet().iterator();

            while(var4.hasNext()) {
               Entry entry = (Entry)var4.next();
               if ((Integer)entry.getValue() != 0) {
                  allSkipped = false;
                  valuesBuilder.a((String)entry.getKey(), (Integer)entry.getValue());
               }
            }

            if (allSkipped) {
               return null;
            } else {
               return (new io.csky.a.e()).a("values", valuesBuilder.a()).a();
            }
         } else {
            return null;
         }
      }
   }

   public static class i extends io.csky.a.c {
      private final Callable<String> a;

      public i(String chartId, Callable<String> callable) {
         super(chartId);
         this.a = callable;
      }

      protected io.csky.a.e.a a() {
         String value = (String)this.a.call();
         return value != null && !value.isEmpty() ? (new io.csky.a.e()).a("value", value).a() : null;
      }
   }
}
