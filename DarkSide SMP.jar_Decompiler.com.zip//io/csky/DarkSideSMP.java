package io.csky;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.plugin.java.JavaPlugin;

public final class DarkSideSMP extends JavaPlugin {
   public io.csky.b.a soulManager;
   public Map<String, FileConfiguration> files = new HashMap();

   public static DarkSideSMP getInstance() {
      return (DarkSideSMP)JavaPlugin.getPlugin(DarkSideSMP.class);
   }

   public void onEnable() {
      this.saveDefaultConfig();
      this.saveDefaultConfig();
      if (!this.getConfig().getBoolean("Terms", false)) {
         this.getLogger().severe(" ");
         this.getLogger().severe("You must accept the license agreement before using this plugin!");
         this.getLogger().severe(" ");
         this.getLogger().severe("To continue:");
         this.getLogger().severe(" - Open the config.yml file in this plugin's folder.");
         this.getLogger().severe(" - Set 'Terms' to true (Terms: true).");
         this.getLogger().severe(" ");
         this.getLogger().severe("License Agreement: https://discord.gg/2Bb86mFzRz");
         this.getLogger().severe(" ");
         this.getLogger().severe("Plugin disabled until terms are accepted.");
         Bukkit.getPluginManager().disablePlugin(this);
      } else {
         File file = new File(this.getDataFolder(), "license.key");
         if (!file.exists()) {
            this.getLogger().severe("You don't have license to use this plugin!");
            this.getLogger().severe(" ");
            this.getLogger().severe("To obtain a valid license, please contact CSky Developments.");
            this.getLogger().severe("Send the following details to receive your license:");
            this.getLogger().severe(" - Server IP: " + b.c(this));
            this.getLogger().severe(" - Port: " + Bukkit.getPort());
            this.getLogger().severe(" - UUID: " + String.valueOf(((World)this.getServer().getWorlds().getFirst()).getUID()));
            this.getLogger().severe(" ");
            this.getLogger().severe("Discord: https://discord.gg/FxxMEaaZJj");
            this.getLogger().severe("Plugin is now disabled.");
            Bukkit.getPluginManager().disablePlugin(this);
         } else {
            try {
               String expected = b.a((JavaPlugin)this);
               String encrypted = b.b(this);
               String decrypted = b.a(encrypted);
               if (!decrypted.equals(expected)) {
                  this.getLogger().severe("Invalid license key!");
                  this.getLogger().severe(" ");
                  this.getLogger().severe("To obtain a valid license, please contact CSky Developments.");
                  this.getLogger().severe("Send the following details to receive your license:");
                  this.getLogger().severe(" - Server IP: " + b.c(this));
                  this.getLogger().severe(" - Port: " + Bukkit.getPort());
                  this.getLogger().severe(" - UUID: " + String.valueOf(((World)this.getServer().getWorlds().getFirst()).getUID()));
                  this.getLogger().severe(" ");
                  this.getLogger().severe("Discord: https://discord.gg/FxxMEaaZJj");
                  this.getLogger().severe("Plugin is now disabled.");
                  Bukkit.getPluginManager().disablePlugin(this);
                  return;
               }

               this.getLogger().info("");
               this.getLogger().info("\u001b[0m\u001b[95m █▀▄ \u001b[0m\u001b[35m█▀█ \u001b[0m\u001b[95m█▀▄ \u001b[0m\u001b[35m█ █ \u001b[0m\u001b[95m█▀▀ \u001b[0m\u001b[35m▀█▀ \u001b[0m\u001b[95m█▀▄ \u001b[0m\u001b[35m█▀▀   \u001b[0m\u001b[91m█▀▀ █▄█ █▀█");
               this.getLogger().info("\u001b[0m\u001b[95m █ █ \u001b[0m\u001b[35m█▀█ \u001b[0m\u001b[95m█▀▄ \u001b[0m\u001b[35m█▀▄ \u001b[0m\u001b[95m▀▀█ \u001b[0m\u001b[35m █  \u001b[0m\u001b[95m█ █ \u001b[0m\u001b[35m█▀▀   \u001b[0m\u001b[91m▀▀█ █ █ █▀▀");
               this.getLogger().info("\u001b[0m\u001b[95m ▀▀  \u001b[0m\u001b[35m▀ ▀ \u001b[0m\u001b[95m▀ ▀ \u001b[0m\u001b[35m▀ ▀ \u001b[0m\u001b[95m▀▀▀ \u001b[0m\u001b[35m▀▀▀ \u001b[0m\u001b[95m▀▀  \u001b[0m\u001b[35m▀▀▀   \u001b[0m\u001b[91m▀▀▀ ▀ ▀ ▀  ");
               this.getLogger().info("\u001b[0m\u001b[37mby C\u001b[0m\u001b[91mS\u001b[0m\u001b[33mk\u001b[0m\u001b[96my \u001b[0m\u001b[37mDevelopments.\u001b[0m");
               this.getLogger().info("");
               this.getLogger().info("\u001b[0m\u001b[35mDarkSide SMP \u001b[0m\u001b[37mhas been enabled successfully!");
               this.soulManager = new io.csky.b.a();
               this.registerRecipes();
               Bukkit.getPluginManager().registerEvents(new io.csky.a.a(), this);
               this.runActionBarTask();
            } catch (Exception var5) {
               this.getLogger().severe("License verification failed: " + var5.getMessage());
               Bukkit.getPluginManager().disablePlugin(this);
            }

         }
      }
   }

   public void onDisable() {
   }

   public void sendError(String info, String error) {
      this.getLogger().severe("ERROR: " + info + " - " + error);
   }

   public FileConfiguration getFile(String name) {
      File file = new File(this.getDataFolder(), name + ".yml");
      if (!file.exists()) {
         file.getParentFile().mkdirs();
         this.saveResource(name + ".yml", false);
      }

      FileConfiguration config = YamlConfiguration.loadConfiguration(file);
      this.files.put(name, config);
      return config;
   }

   public void saveFile(String name) {
      if (this.files.containsKey(name)) {
         try {
            ((FileConfiguration)this.files.get(name)).save(new File(this.getDataFolder(), name + ".yml"));
         } catch (IOException var3) {
            this.sendError("Failed to save " + name + ".yml", var3.getMessage());
         }

      }
   }

   private void registerRecipes() {
      FileConfiguration config = this.getConfig();
      ItemStack essence = this.soulManager.a();
      NamespacedKey keyEssence = new NamespacedKey(this, "essence_of_rebirth");
      ShapedRecipe recipeEssence = new ShapedRecipe(keyEssence, essence);
      recipeEssence.shape(new String[]{"ABC", "DEF", "GHI"});
      char[] slots = "ABCDEFGHI".toCharArray();

      for(int i = 0; i < 9; ++i) {
         Material mat = Material.matchMaterial(config.getString("Essence_Of_Rebirth.Slot" + i, "AIR"));
         recipeEssence.setIngredient(slots[i], mat != null ? mat : Material.AIR);
      }

      Bukkit.addRecipe(recipeEssence);
      ItemStack bottle = this.soulManager.b();
      NamespacedKey keyBottle = new NamespacedKey(this, "spirit_bottle");
      ShapedRecipe recipeBottle = new ShapedRecipe(keyBottle, bottle);
      recipeBottle.shape(new String[]{"ABC", "DEF", "GHI"});

      for(int i = 0; i < 9; ++i) {
         Material mat = Material.matchMaterial(config.getString("Spirit_Bottle.Slot" + i, "AIR"));
         recipeBottle.setIngredient(slots[i], mat != null ? mat : Material.AIR);
      }

      Bukkit.addRecipe(recipeBottle);
   }

   private void runActionBarTask() {
      Bukkit.getScheduler().runTaskTimer(this, () -> {
         Iterator var1 = Bukkit.getOnlinePlayers().iterator();

         while(var1.hasNext()) {
            Player player = (Player)var1.next();
            int souls = this.soulManager.f(player);
            String msg = io.csky.c.a.a("&b" + souls + "/3 ❀ Souls");
            player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(msg));
         }

      }, 0L, 20L);
   }

   private static class a {
      public static final String a = "\u001b[0m";
      public static final String b = "\u001b[0m\u001b[91m";
      public static final String c = "\u001b[0m\u001b[33m";
      public static final String d = "\u001b[0m\u001b[96m";
      public static final String e = "\u001b[0m\u001b[94m";
      public static final String f = "\u001b[0m\u001b[34m";
      public static final String g = "\u001b[0m\u001b[37m";
      public static final String h = "\u001b[0m\u001b[30m";
      public static final String i = "\u001b[0m\u001b[32m";
      public static final String j = "\u001b[0m\u001b[33m";
      public static final String k = "\u001b[0m\u001b[35m";
      public static final String l = "\u001b[0m\u001b[90m";
      public static final String m = "\u001b[0m\u001b[92m";
      public static final String n = "\u001b[0m\u001b[93m";
      public static final String o = "\u001b[0m\u001b[95m";
      public static final String p = "\u001b[0m\u001b[97m";
      public static final String q = "\u001b[0m\u001b[40m";
      public static final String r = "\u001b[0m\u001b[41m";
      public static final String s = "\u001b[0m\u001b[42m";
      public static final String t = "\u001b[0m\u001b[43m";
      public static final String u = "\u001b[0m\u001b[44m";
      public static final String v = "\u001b[0m\u001b[45m";
      public static final String w = "\u001b[0m\u001b[46m";
      public static final String x = "\u001b[0m\u001b[47m";
      public static final String y = "\u001b[0m\u001b[100m";
      public static final String z = "\u001b[0m\u001b[101m";
      public static final String A = "\u001b[0m\u001b[102m";
      public static final String B = "\u001b[0m\u001b[103m";
      public static final String C = "\u001b[0m\u001b[104m";
      public static final String D = "\u001b[0m\u001b[105m";
      public static final String E = "\u001b[0m\u001b[106m";
      public static final String F = "\u001b[0m\u001b[107m";
   }
}
