package io.csky.b;

import io.csky.DarkSideSMP;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class a {
   public static final NamespacedKey a = new NamespacedKey(DarkSideSMP.getInstance(), "spirit_bottle");
   public static final NamespacedKey b = new NamespacedKey(DarkSideSMP.getInstance(), "essence_of_rebirth");
   private final Map<String, Integer> c = new HashMap();
   private final List<String> d = new ArrayList();

   public a() {
      this.c();
   }

   private void c() {
      FileConfiguration config = DarkSideSMP.getInstance().getFile("data");
      Iterator var2 = config.getKeys(false).iterator();

      while(var2.hasNext()) {
         String uuid = (String)var2.next();
         this.c.put(uuid, config.getInt(uuid + ".souls", 3));
      }

      this.d.addAll(config.getStringList("BanList"));
   }

   private void d() {
      Bukkit.getScheduler().runTaskAsynchronously(DarkSideSMP.getInstance(), () -> {
         FileConfiguration config = DarkSideSMP.getInstance().getFile("data");
         this.c.forEach((uuid, souls) -> {
            config.set(uuid + ".souls", souls);
         });
         config.set("BanList", this.d);
         DarkSideSMP.getInstance().saveFile("data");
      });
   }

   public void a(Player p) {
      this.c.put(p.getUniqueId().toString(), 3);
      this.d();
   }

   public boolean b(Player p) {
      return this.c.containsKey(p.getUniqueId().toString());
   }

   public void c(Player p) {
      this.c.put(p.getUniqueId().toString(), this.f(p) + 1);
      this.d();
   }

   public void d(Player p) {
      this.c.put(p.getUniqueId().toString(), Math.max(this.f(p) - 1, 0));
      this.d();
   }

   public void e(Player p) {
      this.c.put(p.getUniqueId().toString(), 3);
      this.d();
   }

   public int f(Player p) {
      return (Integer)this.c.getOrDefault(p.getUniqueId().toString(), 3);
   }

   public void g(Player p) {
      if (!this.d.contains(p.getUniqueId().toString())) {
         this.d.add(p.getUniqueId().toString());
      }

      this.d();
   }

   public boolean h(Player p) {
      return this.d.contains(p.getUniqueId().toString());
   }

   public void i(Player p) {
      this.d.remove(p.getUniqueId().toString());
      this.d();
   }

   public ItemStack a() {
      ItemStack item = new ItemStack(Material.HEART_OF_THE_SEA);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(io.csky.c.a.a("&cEmpty Essence of Rebirth"));
         List lore = List.of(io.csky.c.a.a("&r "), io.csky.c.a.a("&8 A haunting essence bound to lost souls."), io.csky.c.a.a("&8 It throbs with eerie energy, yearning to"), io.csky.c.a.a("&8 escape back to the realm of the living."), io.csky.c.a.a("&8 To awaken the departed, rename me to the"), io.csky.c.a.a("&8 name of the tormented soul."), io.csky.c.a.a("&r "), io.csky.c.a.a("&c&lGHOSTY ITEM"));
         meta.setLore(lore);
         meta.setCustomModelData(2042007);
         meta.getPersistentDataContainer().set(b, PersistentDataType.STRING, "ESSENCE");
         item.setItemMeta(meta);
      }

      return item;
   }

   public ItemStack b() {
      ItemStack item = new ItemStack(Material.LIGHT_BLUE_DYE);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(io.csky.c.a.a("&9Spirit Bottle"));
         List lore = List.of(io.csky.c.a.a("&r "), io.csky.c.a.a("&7 Soul: +1"), io.csky.c.a.a("&8 A vessel of tormented souls, trapped"), io.csky.c.a.a("&8 in eternal anguish. Within its glassy"), io.csky.c.a.a("&8 prison, whispers echo from the beyond,"), io.csky.c.a.a("&8 calling for release into the living world."), io.csky.c.a.a("&8 Feel the cold touch of the departed,"), io.csky.c.a.a("&8 as their essence yearns for freedom."), io.csky.c.a.a("&r"), io.csky.c.a.a("&9&lGHOSTY ITEM"));
         meta.setLore(lore);
         meta.setCustomModelData(2042008);
         meta.getPersistentDataContainer().set(a, PersistentDataType.STRING, "SPIRIT_BOTTLE");
         item.setItemMeta(meta);
      }

      return item;
   }
}
