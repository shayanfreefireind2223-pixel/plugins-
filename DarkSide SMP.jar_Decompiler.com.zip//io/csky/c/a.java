package io.csky.c;

import java.util.regex.Pattern;
import net.md_5.bungee.api.ChatColor;

public class a {
   private static final Pattern a = Pattern.compile("&#([A-Fa-f0-9]{6})");

   public static String a(String text) {
      if (text != null && !text.isEmpty()) {
         String withHex = a.matcher(text).replaceAll((ctx) -> {
            String hex = ctx.group(1);
            return ChatColor.of("#" + hex).toString();
         });
         String translated = ChatColor.translateAlternateColorCodes('&', withHex);
         return translated + String.valueOf(ChatColor.RESET);
      } else {
         return ChatColor.RESET.toString();
      }
   }
}
