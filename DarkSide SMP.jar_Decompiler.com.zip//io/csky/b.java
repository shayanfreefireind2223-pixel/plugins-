package io.csky;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.plugin.java.JavaPlugin;

public class b {
   private static final String a = "8gduA7UFnoWf941EihFEMLUuNaSld6VI";
   private static final String b = "hnvOb8Jqm8ZY14dT";
   private static final String c = "GEamIHJrrOZyFo0N";

   public static String a(JavaPlugin plugin) {
      String ip = c(plugin);
      int port = Bukkit.getPort();
      UUID uuid = ((World)plugin.getServer().getWorlds().getFirst()).getUID();
      String input = ip + ":" + port + ":" + String.valueOf(uuid) + ":8gduA7UFnoWf941EihFEMLUuNaSld6VI";
      MessageDigest digest = MessageDigest.getInstance("SHA-256");
      byte[] hash = digest.digest(input.getBytes());
      return Base64.getEncoder().encodeToString(hash);
   }

   public static String b(JavaPlugin plugin) {
      File file = new File(plugin.getDataFolder(), "license.key");
      if (!file.exists()) {
         throw new Exception("Missing license.key file");
      } else {
         List lines = Files.readAllLines(file.toPath());
         boolean inBlock = false;
         Iterator var4 = lines.iterator();

         while(var4.hasNext()) {
            String line = (String)var4.next();
            line = line.trim();
            if (line.equals("-----BEGIN LICENSE KEY-----")) {
               inBlock = true;
            } else {
               if (line.equals("-----END LICENSE KEY-----")) {
                  break;
               }

               if (inBlock && !line.isEmpty()) {
                  return line;
               }
            }
         }

         throw new Exception("License key block not found in license.key file");
      }
   }

   public static String a(String base64) {
      byte[] encrypted = Base64.getDecoder().decode(base64);
      Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
      SecretKeySpec key = new SecretKeySpec("hnvOb8Jqm8ZY14dT".getBytes(), "AES");
      IvParameterSpec iv = new IvParameterSpec("GEamIHJrrOZyFo0N".getBytes());
      cipher.init(2, key, iv);
      byte[] decrypted = cipher.doFinal(encrypted);
      return new String(decrypted);
   }

   public static String c(JavaPlugin plugin) {
      String result = "Unknow";

      try {
         Enumeration interfaces = NetworkInterface.getNetworkInterfaces();

         label53:
         while(true) {
            while(true) {
               NetworkInterface iface;
               do {
                  do {
                     do {
                        if (!interfaces.hasMoreElements()) {
                           break label53;
                        }

                        iface = (NetworkInterface)interfaces.nextElement();
                     } while(iface.isLoopback());
                  } while(!iface.isUp());
               } while(iface.isVirtual());

               Enumeration addresses = iface.getInetAddresses();

               while(addresses.hasMoreElements()) {
                  InetAddress addr = (InetAddress)addresses.nextElement();
                  if (addr instanceof Inet4Address && !addr.isLoopbackAddress()) {
                     result = addr.getHostAddress();
                     break;
                  }
               }
            }
         }
      } catch (SocketException var7) {
         plugin.getLogger().severe("Error getting local IP: " + var7.getMessage());
      }

      try {
         URL url = new URL("https://api.ipify.org");
         BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
         String publicIp = in.readLine();
         in.close();
         result = publicIp;
      } catch (IOException var6) {
         plugin.getLogger().severe("Error getting public IP: " + var6.getMessage());
      }

      return result;
   }
}
