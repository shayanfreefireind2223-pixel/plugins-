package io.csky.a;

import io.csky.DarkSideSMP;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class a implements Listener {
   private final io.csky.b.a b;
   public final NamespacedKey a;

   public a() {
      this.b = DarkSideSMP.getInstance().soulManager;
      this.a = new NamespacedKey(DarkSideSMP.getInstance(), "essence_target");
   }

   @EventHandler
   public void a(PlayerDeathEvent event) {
      Player player = event.getEntity();
      Player killer = player.getKiller();
      if (killer != null && !killer.equals(player)) {
         int souls = this.b.f(player);
         if (souls > 0 && souls < 4) {
            String var10001;
            if (souls == 1) {
               var10001 = player.getName();
               event.setDeathMessage(io.csky.c.a.a("&8&lDARK&7&lSIDE &f&lSMP &fPlayer &c" + var10001 + "&f has lost all souls and is banished... &oKilled by " + killer.getName()));
               Bukkit.getOnlinePlayers().forEach((p) -> {
                  p.playSound(p.getLocation(), Sound.ENTITY_WITHER_DEATH, 1.0F, 1.0F);
               });
               this.b.d(player);
               player.setGameMode(GameMode.SPECTATOR);
               player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, Integer.MAX_VALUE, 0, false, false, false));
               this.b.g(player);
               return;
            }

            this.b.d(player);
            var10001 = player.getName();
            event.setDeathMessage(io.csky.c.a.a("&8&lDARK&7&lSIDE &f&lSMP &fPlayer &c" + var10001 + "&f has lost a soul killed by " + killer.getName()));
            Bukkit.getOnlinePlayers().forEach((p) -> {
               p.playSound(p.getLocation(), Sound.ENTITY_WITHER_HURT, 1.0F, 1.0F);
            });
         }

      }
   }

   @EventHandler
   public void a(PrepareAnvilEvent event) {
      ItemStack result = event.getResult();
      if (result != null) {
         ItemStack item1 = event.getInventory().getItem(0);
         if (item1 != null) {
            ItemMeta meta = item1.getItemMeta();
            if (meta != null) {
               PersistentDataContainer container = meta.getPersistentDataContainer();
               if (container.has(io.csky.b.a.b)) {
                  if (event.getViewers().isEmpty()) {
                     return;
                  }

                  HumanEntity viewer = (HumanEntity)event.getViewers().getFirst();
                  if (!(viewer instanceof Player)) {
                     return;
                  }

                  Player player = (Player)viewer;
                  ItemMeta resultMeta = result.getItemMeta();
                  if (resultMeta == null) {
                     return;
                  }

                  String typedName = resultMeta.hasDisplayName() ? resultMeta.getDisplayName() : "";
                  if (typedName.isEmpty()) {
                     return;
                  }

                  Player target = Bukkit.getPlayerExact(typedName);
                  if (target == null || !target.isOnline()) {
                     player.playSound(player.getLocation(), Sound.BLOCK_SOUL_SOIL_STEP, 1.0F, 1.0F);
                     event.setResult((ItemStack)null);
                     return;
                  }

                  resultMeta.setDisplayName(io.csky.c.a.a("&cEssence of Rebirth"));
                  List lore = List.of(io.csky.c.a.a("&r "), io.csky.c.a.a("&7 Essence for:&f " + target.getName()), io.csky.c.a.a("&8 A ghastly essence tied to lost souls."), io.csky.c.a.a("&8 It pulsates with eerie energy, yearning"), io.csky.c.a.a("&8 to return to the realm of the living."), io.csky.c.a.a("&8 To revive the dead, right-click me"), io.csky.c.a.a("&r "), io.csky.c.a.a("&c&lGHOSTY SMP ITEM"));
                  resultMeta.setLore(lore);
                  resultMeta.getPersistentDataContainer().set(this.a, PersistentDataType.STRING, target.getUniqueId().toString());
                  result.setItemMeta(resultMeta);
                  event.setResult(result);
               }

            }
         }
      }
   }

   @EventHandler
   public void a(PlayerInteractEvent event) {
      Player player = event.getPlayer();
      if (this.b.h(player)) {
         event.setCancelled(true);
      } else {
         ItemStack item = player.getInventory().getItemInMainHand();
         if (item.getType() != Material.AIR) {
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
               if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
                  PersistentDataContainer container = meta.getPersistentDataContainer();
                  if (container.has(io.csky.b.a.a)) {
                     int souls = this.b.f(player);
                     if (souls < 3) {
                        item.setAmount(item.getAmount() - 1);
                        this.b.c(player);
                        player.sendMessage(io.csky.c.a.a("&8&lDARK&7&lSIDE &f&lSMP &fA soul has been restored to your essence!"));
                        player.playSound(player.getLocation(), Sound.ENTITY_ZOMBIE_VILLAGER_CONVERTED, 1.0F, 1.0F);
                     } else {
                        player.sendMessage(io.csky.c.a.a("&8&lDARK&7&lSIDE &f&lSMP &fYour soul is already at its maximum capacity."));
                        player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
                     }

                  } else {
                     if (container.has(io.csky.b.a.b)) {
                        String uuidString = (String)meta.getPersistentDataContainer().get(this.a, PersistentDataType.STRING);
                        if (uuidString == null) {
                           player.sendMessage(io.csky.c.a.a("&8&lDARK&7&lSIDE &f&lSMP &fYou must type the name of a player in the anvil to bind this essence."));
                           return;
                        }

                        UUID targetUUID;
                        try {
                           targetUUID = UUID.fromString(uuidString);
                        } catch (IllegalArgumentException var9) {
                           player.sendMessage(io.csky.c.a.a("&8&lDARK&7&lSIDE &f&lSMP &fThe essence seems corrupted. It cannot find its destined soul. Craft a new one or try renaming it."));
                           player.playSound(player.getLocation(), Sound.BLOCK_SOUL_SOIL_STEP, 1.0F, 1.0F);
                           return;
                        }

                        Player target = Bukkit.getPlayer(targetUUID);
                        if (target == null) {
                           player.sendMessage(io.csky.c.a.a("&8&lDARK&7&lSIDE &f&lSMP &fThis soul cannot be returned to the living realm."));
                           player.playSound(player.getLocation(), Sound.BLOCK_SOUL_SOIL_STEP, 1.0F, 1.0F);
                           return;
                        }

                        if (!this.b.h(target)) {
                           player.sendMessage(io.csky.c.a.a("&8&lDARK&7&lSIDE &f&lSMP &fThis soul is already living in this realm."));
                           player.playSound(player.getLocation(), Sound.BLOCK_SOUL_SOIL_STEP, 1.0F, 1.0F);
                           return;
                        }

                        this.b.i(target);
                        this.b.e(target);
                        target.setGameMode(GameMode.SURVIVAL);
                        target.removePotionEffect(PotionEffectType.BLINDNESS);
                        item.setAmount(item.getAmount() - 1);
                        Bukkit.getOnlinePlayers().forEach((p) -> {
                           String var10001 = player.getName();
                           p.sendMessage(io.csky.c.a.a("&5&lDARK&d&lSIDE &f&lSMP &b" + var10001 + " &fhas restored the soul of &c" + target.getName() + "&f to the living realm."));
                        });
                        Bukkit.getOnlinePlayers().forEach((p) -> {
                           p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 1.0F, 1.0F);
                        });
                     }

                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void a(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      if (!this.b.b(player)) {
         this.b.a(player);
      }

      this.a(player);
   }

   @EventHandler
   public void a(PlayerRespawnEvent event) {
      this.a(event.getPlayer());
   }

   private void a(Player player) {
      if (this.b.h(player)) {
         player.setGameMode(GameMode.SPECTATOR);
         if (!player.hasPotionEffect(PotionEffectType.BLINDNESS)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, Integer.MAX_VALUE, 0, false, false, false));
         }
      }

   }

   @EventHandler
   public void a(PlayerMoveEvent event) {
      if (this.b.h(event.getPlayer())) {
         event.setCancelled(true);
      }

   }

   @EventHandler
   public void a(PlayerDropItemEvent event) {
      if (this.b.h(event.getPlayer())) {
         event.setCancelled(true);
      }

   }

   @EventHandler
   public void a(EntityPickupItemEvent event) {
      LivingEntity var3 = event.getEntity();
      if (var3 instanceof Player) {
         Player player = (Player)var3;
         if (this.b.h(player)) {
            event.setCancelled(true);
         }
      }

   }

   @EventHandler
   public void a(InventoryClickEvent event) {
      if (this.b.h((Player)event.getWhoClicked())) {
         event.setCancelled(true);
      }

   }

   @EventHandler
   public void a(PlayerToggleSneakEvent event) {
      if (this.b.h(event.getPlayer())) {
         event.setCancelled(true);
      }

   }
}
