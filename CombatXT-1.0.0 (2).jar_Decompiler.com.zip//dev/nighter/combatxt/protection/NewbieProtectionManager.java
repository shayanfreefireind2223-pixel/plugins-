package dev.nighter.combatxt.protection;

import dev.nighter.combatxt.CombatXT;
import dev.nighter.combatxt.Scheduler;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import lombok.Generated;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class NewbieProtectionManager {
   private final CombatXT plugin;
   private final File protectionFile;
   private FileConfiguration protectionConfig;
   private final Map<UUID, Long> protectedPlayers = new ConcurrentHashMap();
   private final Map<UUID, BossBar> protectionBossBars = new ConcurrentHashMap();
   private boolean enabled;
   private long protectionDurationTicks;
   private long protectionDurationSeconds;
   private boolean useBossBar;
   private boolean useActionBar;
   private String bossBarTitle;
   private BarColor bossBarColor;
   private BarStyle bossBarStyle;
   private Map<String, Boolean> worldProtectionSettings = new ConcurrentHashMap();
   private boolean protectFromPvP;
   private boolean protectFromMobs;
   private boolean removeOnDamageDealt;
   private Scheduler.Task updateTask;
   private Scheduler.Task cleanupTask;
   private Scheduler.Task saveTask;
   private static final long UPDATE_INTERVAL = 20L;
   private static final long CLEANUP_INTERVAL = 12000L;
   private static final long SAVE_INTERVAL = 6000L;

   public NewbieProtectionManager(CombatXT plugin) {
      this.plugin = plugin;
      this.protectionFile = new File(plugin.getDataFolder(), "newbie_protection_data.yml");
      this.loadConfig();
      this.loadProtectionData();
      this.startUpdateTask();
      this.startCleanupTask();
      this.startAutoSaveTask();
   }

   public void loadConfig() {
      FileConfiguration config = this.plugin.getConfig();
      this.enabled = config.getBoolean("newbie_protection.enabled", true);
      this.protectionDurationTicks = this.plugin.getTimeFromConfig("newbie_protection.duration", "10m");
      this.protectionDurationSeconds = this.protectionDurationTicks / 20L;
      this.useBossBar = config.getBoolean("newbie_protection.display.use_bossbar", true);
      this.useActionBar = config.getBoolean("newbie_protection.display.use_actionbar", false);
      this.bossBarTitle = config.getString("newbie_protection.display.bossbar.title", "&#4CAF50PvP Protection: &#FFFFFF%time%");
      String colorStr = config.getString("newbie_protection.display.bossbar.color", "GREEN");

      try {
         this.bossBarColor = BarColor.valueOf(colorStr.toUpperCase());
      } catch (IllegalArgumentException var6) {
         this.bossBarColor = BarColor.YELLOW;
         this.plugin.getLogger().warning("Invalid boss bar color: " + colorStr + ", using GREEN");
      }

      String styleStr = config.getString("newbie_protection.display.bossbar.style", "SOLID");

      try {
         this.bossBarStyle = BarStyle.valueOf(styleStr.toUpperCase());
      } catch (IllegalArgumentException var5) {
         this.bossBarStyle = BarStyle.SOLID;
         this.plugin.getLogger().warning("Invalid boss bar style: " + styleStr + ", using SOLID");
      }

      this.protectFromPvP = config.getBoolean("newbie_protection.protect_from_pvp", true);
      this.protectFromMobs = config.getBoolean("newbie_protection.protect_from_mobs", false);
      this.removeOnDamageDealt = config.getBoolean("newbie_protection.remove_on_damage_dealt", true);
      this.loadWorldProtectionSettings();
      this.plugin.debug("NewbieProtectionManager config loaded - Enabled: " + this.enabled + ", Duration: " + this.protectionDurationSeconds + "s, Boss bar: " + this.useBossBar + ", Action bar: " + this.useActionBar);
   }

   private void loadWorldProtectionSettings() {
      this.worldProtectionSettings.clear();
      if (this.plugin.getConfig().isConfigurationSection("newbie_protection.worlds")) {
         Iterator var1 = ((ConfigurationSection)Objects.requireNonNull(this.plugin.getConfig().getConfigurationSection("newbie_protection.worlds"))).getKeys(false).iterator();

         while(var1.hasNext()) {
            String worldName = (String)var1.next();
            boolean enabledInWorld = this.plugin.getConfig().getBoolean("newbie_protection.worlds." + worldName, true);
            this.worldProtectionSettings.put(worldName, enabledInWorld);
         }
      }

      this.plugin.debug("Loaded world-specific newbie protection settings: " + String.valueOf(this.worldProtectionSettings));
   }

   private void loadProtectionData() {
      if (!this.protectionFile.exists()) {
         try {
            this.protectionFile.getParentFile().mkdirs();
            this.protectionFile.createNewFile();
            this.plugin.debug("Created new newbie_protection_data.yml file");
         } catch (IOException var10) {
            this.plugin.getLogger().severe("Failed to create newbie_protection_data.yml: " + var10.getMessage());
            return;
         }
      }

      this.protectionConfig = YamlConfiguration.loadConfiguration(this.protectionFile);
      int loadedCount = 0;
      long currentTime = System.currentTimeMillis();
      Iterator var4 = this.protectionConfig.getKeys(false).iterator();

      while(var4.hasNext()) {
         String uuidStr = (String)var4.next();

         try {
            UUID playerUUID = UUID.fromString(uuidStr);
            long expirationTime = this.protectionConfig.getLong(uuidStr);
            if (expirationTime > currentTime) {
               this.protectedPlayers.put(playerUUID, expirationTime);
               ++loadedCount;
            }
         } catch (IllegalArgumentException var9) {
            this.plugin.getLogger().warning("Invalid UUID in protection data: " + uuidStr);
         }
      }

      this.plugin.getLogger().info("Loaded " + loadedCount + " active newbie protections");
   }

   public void saveProtectionData() {
      this.saveProtectionData(false);
   }

   public void saveProtectionData(boolean synchronous) {
      if (this.protectionConfig == null) {
         this.protectionConfig = new YamlConfiguration();
      }

      Iterator var2 = this.protectionConfig.getKeys(false).iterator();

      while(var2.hasNext()) {
         String key = (String)var2.next();
         this.protectionConfig.set(key, (Object)null);
      }

      long currentTime = System.currentTimeMillis();
      Iterator var5 = this.protectedPlayers.entrySet().iterator();

      while(var5.hasNext()) {
         Entry<UUID, Long> entry = (Entry)var5.next();
         if ((Long)entry.getValue() > currentTime) {
            this.protectionConfig.set(((UUID)entry.getKey()).toString(), entry.getValue());
         }
      }

      if (!synchronous && this.plugin.isEnabled()) {
         Scheduler.runTaskAsync(() -> {
            try {
               this.protectionConfig.save(this.protectionFile);
               this.plugin.debug("Saved newbie protection data to file");
            } catch (IOException var2) {
               this.plugin.getLogger().severe("Failed to save newbie_protection_data.yml: " + var2.getMessage());
            }

         });
      } else {
         try {
            this.protectionConfig.save(this.protectionFile);
            this.plugin.debug("Saved newbie protection data to file (synchronous)");
         } catch (IOException var7) {
            this.plugin.getLogger().severe("Failed to save newbie_protection_data.yml: " + var7.getMessage());
         }
      }

   }

   public boolean isEnabledInWorld(String worldName) {
      return !this.enabled ? false : (Boolean)this.worldProtectionSettings.getOrDefault(worldName, true);
   }

   public void grantProtection(Player player) {
      if (this.enabled && player != null) {
         String worldName = player.getWorld().getName();
         if (!this.isEnabledInWorld(worldName)) {
            this.plugin.debug("Newbie protection not enabled in world: " + worldName);
         } else {
            UUID playerUUID = player.getUniqueId();
            long expirationTime = System.currentTimeMillis() + this.protectionDurationSeconds * 1000L;
            this.protectedPlayers.put(playerUUID, expirationTime);
            if (this.useBossBar) {
               this.createBossBar(player);
            }

            Map<String, String> placeholders = new HashMap();
            placeholders.put("player", player.getName());
            placeholders.put("duration", this.formatTime(this.protectionDurationSeconds));
            this.plugin.getMessageService().sendMessage((Player)player, "newbie_protection_granted", placeholders);
            CombatXT var10000 = this.plugin;
            String var10001 = player.getName();
            var10000.debug("Granted newbie protection to " + var10001 + " until " + String.valueOf(new Date(expirationTime)));
         }
      }

   }

   public boolean hasProtection(Player player) {
      if (this.enabled && player != null) {
         String worldName = player.getWorld().getName();
         if (!this.isEnabledInWorld(worldName)) {
            return false;
         } else {
            UUID playerUUID = player.getUniqueId();
            Long expirationTime = (Long)this.protectedPlayers.get(playerUUID);
            if (expirationTime == null) {
               return false;
            } else {
               long currentTime = System.currentTimeMillis();
               if (currentTime >= expirationTime) {
                  this.removeProtection(player, false);
                  return false;
               } else {
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   public void removeProtection(Player player, boolean sendMessage) {
      if (player != null) {
         UUID playerUUID = player.getUniqueId();
         boolean hadProtection = this.protectedPlayers.remove(playerUUID) != null;
         if (hadProtection) {
            BossBar bossBar = (BossBar)this.protectionBossBars.remove(playerUUID);
            if (bossBar != null) {
               bossBar.removeAll();
            }

            this.plugin.debug("Removed newbie protection from " + player.getName());
         }
      }

   }

   public boolean handleDamageReceived(Player player, Player attacker) {
      if (!this.hasProtection(player)) {
         return false;
      } else {
         if (attacker != null && attacker != player) {
            Map<String, String> placeholders = new HashMap();
            placeholders.put("player", player.getName());
            placeholders.put("attacker", attacker.getName());
            this.plugin.getMessageService().sendMessage((Player)attacker, "newbie_protection_attack_blocked", placeholders);
         }

         return true;
      }
   }

   public void handleDamageDealt(Player player) {
      if (this.removeOnDamageDealt && this.hasProtection(player)) {
         Map<String, String> placeholders = new HashMap();
         placeholders.put("player", player.getName());
         this.plugin.getMessageService().sendMessage((Player)player, "newbie_protection_removed_attack", placeholders);
         this.removeProtection(player, false);
      }

   }

   public long getRemainingTime(Player player) {
      if (!this.hasProtection(player)) {
         return 0L;
      } else {
         UUID playerUUID = player.getUniqueId();
         Long expirationTime = (Long)this.protectedPlayers.get(playerUUID);
         if (expirationTime == null) {
            return 0L;
         } else {
            long remainingMillis = expirationTime - System.currentTimeMillis();
            return Math.max(0L, remainingMillis / 1000L);
         }
      }
   }

   private void createBossBar(Player player) {
      if (this.useBossBar && player != null) {
         UUID playerUUID = player.getUniqueId();
         BossBar existingBar = (BossBar)this.protectionBossBars.get(playerUUID);
         if (existingBar != null) {
            existingBar.removeAll();
         }

         String title = this.bossBarTitle.replace("%time%", this.formatTime(this.getRemainingTime(player)));
         title = this.plugin.getLanguageManager().colorize(title);
         BossBar bossBar = Bukkit.createBossBar(title, this.bossBarColor, this.bossBarStyle, new BarFlag[0]);
         bossBar.setProgress(1.0D);
         bossBar.addPlayer(player);
         this.protectionBossBars.put(playerUUID, bossBar);
      }

   }

   private void updateBossBar(Player player) {
      if (this.useBossBar && player != null) {
         UUID playerUUID = player.getUniqueId();
         BossBar bossBar = (BossBar)this.protectionBossBars.get(playerUUID);
         if (bossBar != null) {
            long remainingTime = this.getRemainingTime(player);
            if (remainingTime <= 0L) {
               bossBar.removeAll();
               this.protectionBossBars.remove(playerUUID);
            } else {
               String title = this.bossBarTitle.replace("%time%", this.formatTime(remainingTime));
               title = this.plugin.getLanguageManager().colorize(title);
               bossBar.setTitle(title);
               double progress = Math.max(0.0D, Math.min(1.0D, (double)remainingTime / (double)this.protectionDurationSeconds));
               bossBar.setProgress(progress);
            }
         }
      }

   }

   private void sendActionBar(Player player) {
      if (this.useActionBar && player != null && player.isOnline()) {
         long remainingTime = this.getRemainingTime(player);
         if (remainingTime > 0L) {
            Map<String, String> placeholders = new HashMap();
            placeholders.put("player", player.getName());
            placeholders.put("time", this.formatTime(remainingTime));
            this.plugin.getMessageService().sendMessage((Player)player, "newbie_protection_actionbar", placeholders);
         }
      }

   }

   private String formatTime(long seconds) {
      if (seconds <= 0L) {
         return "0s";
      } else {
         long hours = seconds / 3600L;
         long minutes = seconds % 3600L / 60L;
         long secs = seconds % 60L;
         StringBuilder sb = new StringBuilder();
         if (hours > 0L) {
            sb.append(hours).append("h ");
         }

         if (minutes > 0L) {
            sb.append(minutes).append("m ");
         }

         if (secs > 0L || sb.length() == 0) {
            sb.append(secs).append("s");
         }

         return sb.toString().trim();
      }
   }

   private void startUpdateTask() {
      if (this.updateTask != null) {
         this.updateTask.cancel();
      }

      this.updateTask = Scheduler.runTaskTimer(() -> {
         Iterator var1 = (new HashSet(this.protectedPlayers.keySet())).iterator();

         while(var1.hasNext()) {
            UUID playerUUID = (UUID)var1.next();
            Player player = Bukkit.getPlayer(playerUUID);
            if (player != null && player.isOnline() && this.hasProtection(player)) {
               if (this.useBossBar) {
                  this.updateBossBar(player);
               }

               if (this.useActionBar) {
                  this.sendActionBar(player);
               }
            }
         }

      }, 0L, 20L);
   }

   private void startCleanupTask() {
      if (this.cleanupTask != null) {
         this.cleanupTask.cancel();
      }

      this.cleanupTask = Scheduler.runTaskTimerAsync(() -> {
         long currentTime = System.currentTimeMillis();
         int removedCount = 0;
         Iterator iterator = this.protectedPlayers.entrySet().iterator();

         while(iterator.hasNext()) {
            Entry<UUID, Long> entry = (Entry)iterator.next();
            if (currentTime >= (Long)entry.getValue()) {
               UUID playerUUID = (UUID)entry.getKey();
               iterator.remove();
               Scheduler.runTask(() -> {
                  BossBar bossBar = (BossBar)this.protectionBossBars.remove(playerUUID);
                  if (bossBar != null) {
                     bossBar.removeAll();
                  }

               });
               ++removedCount;
            }
         }

         if (removedCount > 0) {
            this.plugin.debug("Cleaned up " + removedCount + " expired newbie protections");
         }

      }, 12000L, 12000L);
   }

   private void startAutoSaveTask() {
      if (this.saveTask != null) {
         this.saveTask.cancel();
      }

      this.saveTask = Scheduler.runTaskTimerAsync(this::saveProtectionData, 6000L, 6000L);
   }

   public void clearPlayerProtection(Player player) {
      if (player != null) {
         this.removeProtection(player, false);
         this.plugin.debug("Manually cleared newbie protection for " + player.getName());
      }

   }

   public void reloadConfig() {
      this.loadConfig();
      this.plugin.debug("NewbieProtectionManager configuration reloaded");
   }

   public void handlePlayerJoin(Player player) {
      if (this.enabled && player != null) {
         if (player.hasPlayedBefore()) {
            this.plugin.debug("Player " + player.getName() + " has played before, not granting newbie protection");
         } else {
            this.grantProtection(player);
         }
      }

   }

   public void handlePlayerQuit(Player player) {
      if (player != null) {
         UUID playerUUID = player.getUniqueId();
         BossBar bossBar = (BossBar)this.protectionBossBars.remove(playerUUID);
         if (bossBar != null) {
            bossBar.removeAll();
         }
      }

   }

   public boolean shouldProtectFromPvP() {
      return this.protectFromPvP;
   }

   public boolean shouldProtectFromMobs() {
      return this.protectFromMobs;
   }

   public void shutdown() {
      if (this.updateTask != null) {
         this.updateTask.cancel();
         this.updateTask = null;
      }

      if (this.cleanupTask != null) {
         this.cleanupTask.cancel();
         this.cleanupTask = null;
      }

      if (this.saveTask != null) {
         this.saveTask.cancel();
         this.saveTask = null;
      }

      Iterator var1 = this.protectionBossBars.values().iterator();

      while(var1.hasNext()) {
         BossBar bossBar = (BossBar)var1.next();
         bossBar.removeAll();
      }

      this.protectionBossBars.clear();
      this.saveProtectionData(true);
      this.protectedPlayers.clear();
   }

   @Generated
   public Map<UUID, Long> getProtectedPlayers() {
      return this.protectedPlayers;
   }
}
