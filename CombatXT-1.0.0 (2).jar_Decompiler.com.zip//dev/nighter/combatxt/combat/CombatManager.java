package dev.nighter.combatxt.combat;

import dev.nighter.combatxt.CombatXT;
import dev.nighter.combatxt.Scheduler;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import lombok.Generated;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class CombatManager {
   private final CombatXT plugin;
   private final Map<UUID, Long> playersInCombat;
   private final Map<UUID, Scheduler.Task> combatTasks;
   private final Map<UUID, UUID> combatOpponents;
   private Scheduler.Task globalCountdownTask;
   private static final long COUNTDOWN_INTERVAL = 20L;
   private final Map<UUID, Long> enderPearlCooldowns;
   private final Map<UUID, Long> tridentCooldowns = new ConcurrentHashMap();
   private final Map<UUID, BossBar> combatBossBars = new ConcurrentHashMap();
   private long combatDurationTicks;
   private long combatDurationSeconds;
   private boolean disableFlightInCombat;
   private long enderPearlCooldownTicks;
   private long enderPearlCooldownSeconds;
   private Map<String, Boolean> worldEnderPearlSettings = new ConcurrentHashMap();
   private boolean enderPearlInCombatOnly;
   private boolean enderPearlEnabled;
   private boolean refreshCombatOnPearlLand;
   private long tridentCooldownTicks;
   private long tridentCooldownSeconds;
   private Map<String, Boolean> worldTridentSettings = new ConcurrentHashMap();
   private boolean tridentInCombatOnly;
   private boolean tridentEnabled;
   private boolean refreshCombatOnTridentLand;
   private Map<String, Boolean> worldTridentBannedSettings = new ConcurrentHashMap();
   private Scheduler.Task cleanupTask;
   private static final long CLEANUP_INTERVAL = 12000L;

   public CombatManager(CombatXT plugin) {
      this.plugin = plugin;
      this.playersInCombat = new ConcurrentHashMap();
      this.combatTasks = new ConcurrentHashMap();
      this.combatOpponents = new ConcurrentHashMap();
      this.enderPearlCooldowns = new ConcurrentHashMap();
      this.combatDurationTicks = plugin.getTimeFromConfig("combat.duration", "20s");
      this.combatDurationSeconds = this.combatDurationTicks / 20L;
      this.disableFlightInCombat = plugin.getConfig().getBoolean("combat.disable_flight", true);
      this.enderPearlCooldownTicks = plugin.getTimeFromConfig("enderpearl_cooldown.duration", "10s");
      this.enderPearlCooldownSeconds = this.enderPearlCooldownTicks / 20L;
      this.enderPearlEnabled = plugin.getConfig().getBoolean("enderpearl_cooldown.enabled", true);
      this.enderPearlInCombatOnly = plugin.getConfig().getBoolean("enderpearl_cooldown.in_combat_only", true);
      this.refreshCombatOnPearlLand = plugin.getConfig().getBoolean("enderpearl.refresh_combat_on_land", false);
      this.tridentCooldownTicks = plugin.getTimeFromConfig("trident_cooldown.duration", "10s");
      this.tridentCooldownSeconds = this.tridentCooldownTicks / 20L;
      this.tridentEnabled = plugin.getConfig().getBoolean("trident_cooldown.enabled", true);
      this.tridentInCombatOnly = plugin.getConfig().getBoolean("trident_cooldown.in_combat_only", true);
      this.refreshCombatOnTridentLand = plugin.getConfig().getBoolean("trident.refresh_combat_on_land", false);
      this.loadWorldTridentSettings();
      this.loadWorldEnderPearlSettings();
      this.startGlobalCountdownTimer();
   }

   private void loadWorldTridentSettings() {
      this.worldTridentSettings.clear();
      this.worldTridentBannedSettings.clear();
      Iterator var1;
      String worldName;
      boolean banned;
      if (this.plugin.getConfig().isConfigurationSection("trident_cooldown.worlds")) {
         var1 = ((ConfigurationSection)Objects.requireNonNull(this.plugin.getConfig().getConfigurationSection("trident_cooldown.worlds"))).getKeys(false).iterator();

         while(var1.hasNext()) {
            worldName = (String)var1.next();
            banned = this.plugin.getConfig().getBoolean("trident_cooldown.worlds." + worldName, true);
            this.worldTridentSettings.put(worldName, banned);
         }
      }

      if (this.plugin.getConfig().isConfigurationSection("trident.banned_worlds")) {
         var1 = ((ConfigurationSection)Objects.requireNonNull(this.plugin.getConfig().getConfigurationSection("trident.banned_worlds"))).getKeys(false).iterator();

         while(var1.hasNext()) {
            worldName = (String)var1.next();
            banned = this.plugin.getConfig().getBoolean("trident.banned_worlds." + worldName, false);
            this.worldTridentBannedSettings.put(worldName, banned);
         }
      }

   }

   public void reloadConfig() {
      this.combatDurationTicks = this.plugin.getTimeFromConfig("combat.duration", "20s");
      this.combatDurationSeconds = this.combatDurationTicks / 20L;
      this.disableFlightInCombat = this.plugin.getConfig().getBoolean("combat.disable_flight", true);
      this.enderPearlCooldownTicks = this.plugin.getTimeFromConfig("enderpearl_cooldown.duration", "10s");
      this.enderPearlCooldownSeconds = this.enderPearlCooldownTicks / 20L;
      this.enderPearlEnabled = this.plugin.getConfig().getBoolean("enderpearl_cooldown.enabled", true);
      this.enderPearlInCombatOnly = this.plugin.getConfig().getBoolean("enderpearl_cooldown.in_combat_only", true);
      this.refreshCombatOnPearlLand = this.plugin.getConfig().getBoolean("enderpearl.refresh_combat_on_land", false);
      this.loadWorldEnderPearlSettings();
      this.tridentCooldownTicks = this.plugin.getTimeFromConfig("trident_cooldown.duration", "10s");
      this.tridentCooldownSeconds = this.tridentCooldownTicks / 20L;
      this.tridentEnabled = this.plugin.getConfig().getBoolean("trident_cooldown.enabled", true);
      this.tridentInCombatOnly = this.plugin.getConfig().getBoolean("trident_cooldown.in_combat_only", true);
      this.refreshCombatOnTridentLand = this.plugin.getConfig().getBoolean("trident.refresh_combat_on_land", false);
      this.loadWorldTridentSettings();
   }

   private void loadWorldEnderPearlSettings() {
      this.worldEnderPearlSettings.clear();
      if (this.plugin.getConfig().isConfigurationSection("enderpearl_cooldown.worlds")) {
         Iterator var1 = ((ConfigurationSection)Objects.requireNonNull(this.plugin.getConfig().getConfigurationSection("enderpearl_cooldown.worlds"))).getKeys(false).iterator();

         while(var1.hasNext()) {
            String worldName = (String)var1.next();
            boolean enabled = this.plugin.getConfig().getBoolean("enderpearl_cooldown.worlds." + worldName, true);
            this.worldEnderPearlSettings.put(worldName, enabled);
         }
      }

   }

   private void startGlobalCountdownTimer() {
      if (this.globalCountdownTask != null) {
         this.globalCountdownTask.cancel();
      }

      this.globalCountdownTask = Scheduler.runTaskTimer(() -> {
         long currentTime = System.currentTimeMillis();
         Iterator var3 = (new HashMap(this.playersInCombat)).entrySet().iterator();

         while(true) {
            while(true) {
               while(var3.hasNext()) {
                  Entry<UUID, Long> entry = (Entry)var3.next();
                  UUID playerUUID = (UUID)entry.getKey();
                  long combatEndTime = (Long)entry.getValue();
                  Player player;
                  if (currentTime > combatEndTime) {
                     player = Bukkit.getPlayer(playerUUID);
                     if (player != null && player.isOnline()) {
                        this.removeFromCombat(player);
                     } else {
                        this.playersInCombat.remove(playerUUID);
                        this.combatOpponents.remove(playerUUID);
                        Scheduler.Task task = (Scheduler.Task)this.combatTasks.remove(playerUUID);
                        if (task != null) {
                           task.cancel();
                        }
                     }
                  } else {
                     player = Bukkit.getPlayer(playerUUID);
                     if (player != null && player.isOnline()) {
                        this.updatePlayerCountdown(player, currentTime);
                     }
                  }
               }

               this.enderPearlCooldowns.entrySet().removeIf((entryx) -> {
                  return currentTime > (Long)entryx.getValue() || Bukkit.getPlayer((UUID)entryx.getKey()) == null;
               });
               this.tridentCooldowns.entrySet().removeIf((entryx) -> {
                  return currentTime > (Long)entryx.getValue() || Bukkit.getPlayer((UUID)entryx.getKey()) == null;
               });
               return;
            }
         }
      }, 0L, 20L);
   }

   private void updatePlayerCountdown(Player player, long currentTime) {
      if (player != null && player.isOnline()) {
         UUID playerUUID = player.getUniqueId();
         boolean inCombat = this.playersInCombat.containsKey(playerUUID) && currentTime <= (Long)this.playersInCombat.get(playerUUID);
         boolean hasPearlCooldown = this.enderPearlCooldowns.containsKey(playerUUID) && currentTime <= (Long)this.enderPearlCooldowns.get(playerUUID);
         boolean hasTridentCooldown = this.tridentCooldowns.containsKey(playerUUID) && currentTime <= (Long)this.tridentCooldowns.get(playerUUID);
         if (inCombat) {
            this.updateCombatBossBar(player, currentTime);
         } else {
            this.removeCombatBossBar(player);
         }

         if (inCombat || hasPearlCooldown || hasTridentCooldown) {
            Map<String, String> placeholders = new HashMap();
            placeholders.put("player", player.getName());
            int remainingCombatTime;
            int remainingTridentTime;
            if (inCombat) {
               remainingCombatTime = this.getRemainingCombatTime(player, currentTime);
               placeholders.put("combat_time", String.valueOf(remainingCombatTime));
               if (hasPearlCooldown && hasTridentCooldown) {
                  int remainingPearlTime = this.getRemainingEnderPearlCooldown(player, currentTime);
                  remainingTridentTime = this.getRemainingTridentCooldown(player, currentTime);
                  placeholders.put("pearl_time", String.valueOf(remainingPearlTime));
                  placeholders.put("trident_time", String.valueOf(remainingTridentTime));
                  this.plugin.getMessageService().sendMessage((Player)player, "combat_pearl_trident_countdown", placeholders);
               } else if (hasPearlCooldown) {
                  remainingTridentTime = this.getRemainingEnderPearlCooldown(player, currentTime);
                  placeholders.put("pearl_time", String.valueOf(remainingTridentTime));
                  this.plugin.getMessageService().sendMessage((Player)player, "combat_pearl_countdown", placeholders);
               } else if (hasTridentCooldown) {
                  remainingTridentTime = this.getRemainingTridentCooldown(player, currentTime);
                  placeholders.put("trident_time", String.valueOf(remainingTridentTime));
                  this.plugin.getMessageService().sendMessage((Player)player, "combat_trident_countdown", placeholders);
               } else if (remainingCombatTime > 0) {
                  placeholders.put("time", String.valueOf(remainingCombatTime));
                  this.plugin.getMessageService().sendMessage((Player)player, "combat_countdown", placeholders);
               }
            } else if (hasPearlCooldown && hasTridentCooldown) {
               remainingCombatTime = this.getRemainingEnderPearlCooldown(player, currentTime);
               remainingTridentTime = this.getRemainingTridentCooldown(player, currentTime);
               placeholders.put("pearl_time", String.valueOf(remainingCombatTime));
               placeholders.put("trident_time", String.valueOf(remainingTridentTime));
               this.plugin.getMessageService().sendMessage((Player)player, "pearl_trident_countdown", placeholders);
            } else if (hasPearlCooldown) {
               remainingCombatTime = this.getRemainingEnderPearlCooldown(player, currentTime);
               if (remainingCombatTime > 0) {
                  placeholders.put("time", String.valueOf(remainingCombatTime));
                  this.plugin.getMessageService().sendMessage((Player)player, "pearl_only_countdown", placeholders);
               }
            } else if (hasTridentCooldown) {
               remainingCombatTime = this.getRemainingTridentCooldown(player, currentTime);
               if (remainingCombatTime > 0) {
                  placeholders.put("time", String.valueOf(remainingCombatTime));
                  this.plugin.getMessageService().sendMessage((Player)player, "trident_only_countdown", placeholders);
               }
            }
         }
      }

   }

   public void tagPlayer(Player player, Player attacker) {
      if (player != null && attacker != null && !player.hasPermission("combatxt.bypass.tag")) {
         UUID playerUUID = player.getUniqueId();
         long newEndTime = System.currentTimeMillis() + this.combatDurationSeconds * 1000L;
         boolean alreadyInCombat = this.playersInCombat.containsKey(playerUUID);
         boolean alreadyInCombatWithAttacker = alreadyInCombat && attacker.getUniqueId().equals(this.combatOpponents.get(playerUUID));
         if (alreadyInCombatWithAttacker) {
            long currentEndTime = (Long)this.playersInCombat.get(playerUUID);
            if (newEndTime <= currentEndTime) {
               return;
            }
         }

         if (this.shouldDisableFlight(player) && player.isFlying()) {
            player.setFlying(false);
         }

         this.combatOpponents.put(playerUUID, attacker.getUniqueId());
         this.playersInCombat.put(playerUUID, newEndTime);
         this.createCombatBossBar(player);
         Scheduler.Task existingTask = (Scheduler.Task)this.combatTasks.get(playerUUID);
         if (existingTask != null) {
            existingTask.cancel();
         }
      }

   }

   public void punishCombatLogout(Player player) {
      if (player != null) {
         player.setHealth(0.0D);
         this.removeFromCombat(player);
      }

   }

   public void removeFromCombat(Player player) {
      if (player != null) {
         UUID playerUUID = player.getUniqueId();
         if (this.playersInCombat.containsKey(playerUUID)) {
            this.playersInCombat.remove(playerUUID);
            this.combatOpponents.remove(playerUUID);
            this.removeCombatBossBar(player);
            Scheduler.Task task = (Scheduler.Task)this.combatTasks.remove(playerUUID);
            if (task != null) {
               task.cancel();
            }

            if (player.isOnline()) {
               this.plugin.getMessageService().sendMessage(player, "combat_expired");
            }
         }
      }

   }

   public void removeFromCombatSilently(Player player) {
      if (player != null) {
         UUID playerUUID = player.getUniqueId();
         this.playersInCombat.remove(playerUUID);
         this.combatOpponents.remove(playerUUID);
         this.removeCombatBossBar(player);
         Scheduler.Task task = (Scheduler.Task)this.combatTasks.remove(playerUUID);
         if (task != null) {
            task.cancel();
         }
      }

   }

   public Player getCombatOpponent(Player player) {
      if (player == null) {
         return null;
      } else {
         UUID playerUUID = player.getUniqueId();
         if (!this.playersInCombat.containsKey(playerUUID)) {
            return null;
         } else {
            UUID opponentUUID = (UUID)this.combatOpponents.get(playerUUID);
            return opponentUUID == null ? null : Bukkit.getPlayer(opponentUUID);
         }
      }
   }

   public boolean isInCombat(Player player) {
      if (player == null) {
         return false;
      } else {
         UUID playerUUID = player.getUniqueId();
         if (!this.playersInCombat.containsKey(playerUUID)) {
            return false;
         } else {
            long combatEndTime = (Long)this.playersInCombat.get(playerUUID);
            long currentTime = System.currentTimeMillis();
            if (currentTime > combatEndTime) {
               this.removeFromCombat(player);
               return false;
            } else {
               return true;
            }
         }
      }
   }

   public int getRemainingCombatTime(Player player) {
      return this.getRemainingCombatTime(player, System.currentTimeMillis());
   }

   private int getRemainingCombatTime(Player player, long currentTime) {
      if (player == null) {
         return 0;
      } else {
         UUID playerUUID = player.getUniqueId();
         if (!this.playersInCombat.containsKey(playerUUID)) {
            return 0;
         } else {
            long endTime = (Long)this.playersInCombat.get(playerUUID);
            return (int)Math.ceil(Math.max(0.0D, (double)(endTime - currentTime) / 1000.0D));
         }
      }
   }

   public void updateMutualCombat(Player player1, Player player2) {
      if (player1 != null && player1.isOnline() && player2 != null && player2.isOnline()) {
         this.tagPlayer(player1, player2);
         this.tagPlayer(player2, player1);
      }

   }

   public void setEnderPearlCooldown(Player player) {
      if (player != null && this.enderPearlEnabled) {
         String worldName = player.getWorld().getName();
         if ((!this.worldEnderPearlSettings.containsKey(worldName) || (Boolean)this.worldEnderPearlSettings.get(worldName)) && (!this.enderPearlInCombatOnly || this.isInCombat(player))) {
            this.enderPearlCooldowns.put(player.getUniqueId(), System.currentTimeMillis() + this.enderPearlCooldownSeconds * 1000L);
         }
      }

   }

   public boolean isEnderPearlOnCooldown(Player player) {
      if (player == null) {
         return false;
      } else if (!this.enderPearlEnabled) {
         return false;
      } else {
         String worldName = player.getWorld().getName();
         if (this.worldEnderPearlSettings.containsKey(worldName) && !(Boolean)this.worldEnderPearlSettings.get(worldName)) {
            return false;
         } else if (this.enderPearlInCombatOnly && !this.isInCombat(player)) {
            return false;
         } else {
            UUID playerUUID = player.getUniqueId();
            if (!this.enderPearlCooldowns.containsKey(playerUUID)) {
               return false;
            } else {
               long cooldownEndTime = (Long)this.enderPearlCooldowns.get(playerUUID);
               long currentTime = System.currentTimeMillis();
               if (currentTime > cooldownEndTime) {
                  this.enderPearlCooldowns.remove(playerUUID);
                  return false;
               } else {
                  return true;
               }
            }
         }
      }
   }

   public void refreshCombatOnPearlLand(Player player) {
      if (player != null && this.refreshCombatOnPearlLand && this.isInCombat(player)) {
         UUID playerUUID = player.getUniqueId();
         long newEndTime = System.currentTimeMillis() + this.combatDurationSeconds * 1000L;
         long currentEndTime = (Long)this.playersInCombat.getOrDefault(playerUUID, 0L);
         if (newEndTime > currentEndTime) {
            this.playersInCombat.put(playerUUID, newEndTime);
            this.plugin.debug("Refreshed combat time for " + player.getName() + " due to pearl landing");
         }
      }

   }

   public int getRemainingEnderPearlCooldown(Player player) {
      return this.getRemainingEnderPearlCooldown(player, System.currentTimeMillis());
   }

   private int getRemainingEnderPearlCooldown(Player player, long currentTime) {
      if (player == null) {
         return 0;
      } else {
         UUID playerUUID = player.getUniqueId();
         if (!this.enderPearlCooldowns.containsKey(playerUUID)) {
            return 0;
         } else {
            long endTime = (Long)this.enderPearlCooldowns.get(playerUUID);
            return (int)Math.ceil(Math.max(0.0D, (double)(endTime - currentTime) / 1000.0D));
         }
      }
   }

   public boolean shouldDisableFlight(Player player) {
      if (player == null) {
         return false;
      } else if (this.disableFlightInCombat && this.isInCombat(player)) {
         Map<String, String> placeholders = new HashMap();
         placeholders.put("player", player.getName());
         this.plugin.getMessageService().sendMessage((Player)player, "combat_fly_disabled", placeholders);
         return true;
      } else {
         return false;
      }
   }

   public void setTridentCooldown(Player player) {
      if (player != null && this.tridentEnabled) {
         String worldName = player.getWorld().getName();
         if ((!this.worldTridentSettings.containsKey(worldName) || (Boolean)this.worldTridentSettings.get(worldName)) && (!this.tridentInCombatOnly || this.isInCombat(player))) {
            this.tridentCooldowns.put(player.getUniqueId(), System.currentTimeMillis() + this.tridentCooldownSeconds * 1000L);
         }
      }

   }

   public boolean isTridentOnCooldown(Player player) {
      if (player == null) {
         return false;
      } else if (!this.tridentEnabled) {
         return false;
      } else {
         String worldName = player.getWorld().getName();
         if (this.worldTridentSettings.containsKey(worldName) && !(Boolean)this.worldTridentSettings.get(worldName)) {
            return false;
         } else if (this.tridentInCombatOnly && !this.isInCombat(player)) {
            return false;
         } else {
            UUID playerUUID = player.getUniqueId();
            if (!this.tridentCooldowns.containsKey(playerUUID)) {
               return false;
            } else {
               long cooldownEndTime = (Long)this.tridentCooldowns.get(playerUUID);
               long currentTime = System.currentTimeMillis();
               if (currentTime > cooldownEndTime) {
                  this.tridentCooldowns.remove(playerUUID);
                  return false;
               } else {
                  return true;
               }
            }
         }
      }
   }

   public boolean isTridentBanned(Player player) {
      if (player == null) {
         return false;
      } else {
         String worldName = player.getWorld().getName();
         return (Boolean)this.worldTridentBannedSettings.getOrDefault(worldName, false);
      }
   }

   public void refreshCombatOnTridentLand(Player player) {
      if (player != null && this.refreshCombatOnTridentLand && this.isInCombat(player)) {
         UUID playerUUID = player.getUniqueId();
         long newEndTime = System.currentTimeMillis() + this.combatDurationSeconds * 1000L;
         long currentEndTime = (Long)this.playersInCombat.getOrDefault(playerUUID, 0L);
         if (newEndTime > currentEndTime) {
            this.playersInCombat.put(playerUUID, newEndTime);
            this.plugin.debug("Refreshed combat time for " + player.getName() + " due to trident landing");
         }
      }

   }

   public int getRemainingTridentCooldown(Player player) {
      return this.getRemainingTridentCooldown(player, System.currentTimeMillis());
   }

   private int getRemainingTridentCooldown(Player player, long currentTime) {
      if (player == null) {
         return 0;
      } else {
         UUID playerUUID = player.getUniqueId();
         if (!this.tridentCooldowns.containsKey(playerUUID)) {
            return 0;
         } else {
            long endTime = (Long)this.tridentCooldowns.get(playerUUID);
            return (int)Math.ceil(Math.max(0.0D, (double)(endTime - currentTime) / 1000.0D));
         }
      }
   }

   public void shutdown() {
      if (this.globalCountdownTask != null) {
         this.globalCountdownTask.cancel();
         this.globalCountdownTask = null;
      }

      if (this.cleanupTask != null) {
         this.cleanupTask.cancel();
         this.cleanupTask = null;
      }

      this.combatTasks.values().forEach(Scheduler.Task::cancel);
      this.combatTasks.clear();
      this.playersInCombat.clear();
      this.combatOpponents.clear();
      this.enderPearlCooldowns.clear();
      this.tridentCooldowns.clear();
      this.combatBossBars.values().forEach(BossBar::removeAll);
      this.combatBossBars.clear();
   }

   @Generated
   public Map<UUID, Long> getPlayersInCombat() {
      return this.playersInCombat;
   }

   @Generated
   public Map<UUID, Long> getEnderPearlCooldowns() {
      return this.enderPearlCooldowns;
   }

   @Generated
   public Map<UUID, Long> getTridentCooldowns() {
      return this.tridentCooldowns;
   }

   private void createCombatBossBar(Player player) {
      if (player != null && player.isOnline()) {
         UUID playerUUID = player.getUniqueId();
         BossBar existingBar = (BossBar)this.combatBossBars.get(playerUUID);
         if (existingBar != null) {
            existingBar.removeAll();
         }

         BossBar bossBar = Bukkit.createBossBar("§c⚔ §fCombatXT §c⚔", BarColor.RED, BarStyle.SOLID, new BarFlag[0]);
         bossBar.addPlayer(player);
         this.combatBossBars.put(playerUUID, bossBar);
      }

   }

   private void updateCombatBossBar(Player player, long currentTime) {
      if (player != null && player.isOnline()) {
         UUID playerUUID = player.getUniqueId();
         BossBar bossBar = (BossBar)this.combatBossBars.get(playerUUID);
         if (bossBar != null) {
            int remainingTime = this.getRemainingCombatTime(player, currentTime);
            double progress = Math.max(0.0D, Math.min(1.0D, (double)remainingTime / (double)this.combatDurationSeconds));
            bossBar.setProgress(progress);
            bossBar.setTitle("§c⚔ §fCombatXT §7- §e" + remainingTime + "s §c⚔");
         }
      }

   }

   private void removeCombatBossBar(Player player) {
      if (player != null) {
         UUID playerUUID = player.getUniqueId();
         BossBar bossBar = (BossBar)this.combatBossBars.remove(playerUUID);
         if (bossBar != null) {
            bossBar.removeAll();
         }
      }

   }
}
