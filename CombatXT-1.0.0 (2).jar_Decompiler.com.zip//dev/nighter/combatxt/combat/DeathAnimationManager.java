package dev.nighter.combatxt.combat;

import dev.nighter.combatxt.CombatXT;
import dev.nighter.combatxt.Scheduler;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class DeathAnimationManager {
   private final CombatXT plugin;
   private final Random random = new Random();

   public DeathAnimationManager(CombatXT plugin) {
      this.plugin = plugin;
   }

   public void performDeathAnimation(Player victim, Player killer) {
      if (this.plugin.getConfig().getBoolean("death_animation.enabled", true) && (killer != null || !this.plugin.getConfig().getBoolean("death_animation.only_player_kill", true))) {
         Location deathLocation = victim.getLocation();
         World world = deathLocation.getWorld();
         if (world != null) {
            List<String> availableAnimations = new ArrayList();
            if (this.plugin.getConfig().getBoolean("death_animation.animation.lightning", true)) {
               availableAnimations.add("lightning");
            }

            if (this.plugin.getConfig().getBoolean("death_animation.animation.fire_particles", true)) {
               availableAnimations.add("fire_particles");
            }

            if (!availableAnimations.isEmpty()) {
               String selectedAnimation = (String)availableAnimations.get(this.random.nextInt(availableAnimations.size()));
               Scheduler.runLocationTask(deathLocation, () -> {
                  byte var5 = -1;
                  switch(selectedAnimation.hashCode()) {
                  case 686445258:
                     if (selectedAnimation.equals("lightning")) {
                        var5 = 0;
                     }
                     break;
                  case 962889700:
                     if (selectedAnimation.equals("fire_particles")) {
                        var5 = 1;
                     }
                  }

                  switch(var5) {
                  case 0:
                     this.performLightningAnimation(world, deathLocation);
                     break;
                  case 1:
                     this.performParticleAnimation(world, deathLocation);
                  }

               });
            }
         }
      }

   }

   private void performLightningAnimation(World world, Location location) {
      world.strikeLightningEffect(location);
      world.playSound(location, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0F, 1.0F);
   }

   private void performParticleAnimation(World world, Location location) {
      for(int i = 0; i < 50; ++i) {
         double angle = 6.283185307179586D * (double)i / 50.0D;
         double x = Math.cos(angle) * 2.0D;
         double z = Math.sin(angle) * 2.0D;
         world.spawnParticle(Particle.FLAME, location.clone().add(x, 1.0D, z), 1, 0.1D, 0.1D, 0.1D, 0.05D);
      }

      world.playSound(location, Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 1.0F, 1.0F);
   }
}
