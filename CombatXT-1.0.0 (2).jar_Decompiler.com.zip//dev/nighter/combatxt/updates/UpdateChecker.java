package dev.nighter.combatxt.updates;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.nighter.combatxt.Scheduler;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class UpdateChecker implements Listener {
   private final JavaPlugin plugin;
   private final String projectId = "sJEHxBdW";
   private boolean updateAvailable = false;
   private final String currentVersion;
   private String latestVersion = "";
   private String downloadUrl = "";
   private String directLink = "";
   private static final String CONSOLE_RESET = "\u001b[0m";
   private static final String CONSOLE_BRIGHT_GREEN = "\u001b[92m";
   private static final String CONSOLE_YELLOW = "\u001b[33m";
   private static final String CONSOLE_BRIGHT_BLUE = "\u001b[94m";
   private static final String CONSOLE_LAVENDER = "\u001b[38;5;183m";
   private static final String CONSOLE_PINK = "\u001b[38;5;206m";
   private static final String CONSOLE_DEEP_PINK = "\u001b[38;5;198m";
   private final Map<UUID, LocalDate> notifiedPlayers = new HashMap();

   public UpdateChecker(JavaPlugin plugin) {
      this.plugin = plugin;
      this.currentVersion = plugin.getDescription().getVersion();
      plugin.getServer().getPluginManager().registerEvents(this, plugin);
      this.checkForUpdates().thenAccept((hasUpdate) -> {
         if (hasUpdate) {
            this.displayConsoleUpdateMessage();
         }

      }).exceptionally((ex) -> {
         plugin.getLogger().warning("Failed to check for updates: " + ex.getMessage());
         return null;
      });
   }

   private void displayConsoleUpdateMessage() {
      String modrinthLink = "https://modrinth.com/plugin/sJEHxBdW/version/" + this.latestVersion;
      String frameColor = "\u001b[94m";
      this.plugin.getLogger().info(frameColor + "────────────────────────────────────────────────────\u001b[0m");
      this.plugin.getLogger().info(frameColor + "\u001b[92m         \ud83c\udf1f CombatXT Update Available \ud83c\udf1f\u001b[0m");
      this.plugin.getLogger().info(frameColor + "────────────────────────────────────────────────────\u001b[0m");
      this.plugin.getLogger().info("");
      this.plugin.getLogger().info(frameColor + "\u001b[0m\ud83d\udce6 Current version: \u001b[33m" + this.formatConsoleText(this.currentVersion, 31) + "\u001b[0m");
      this.plugin.getLogger().info(frameColor + "\u001b[0m✅ Latest version: \u001b[92m" + this.formatConsoleText(this.latestVersion, 32) + "\u001b[0m");
      this.plugin.getLogger().info("");
      this.plugin.getLogger().info(frameColor + "\u001b[0m\ud83d\udce5 Download the latest version at:\u001b[0m");
      this.plugin.getLogger().info(frameColor + " \u001b[92m" + this.formatConsoleText(modrinthLink, 51) + "\u001b[0m");
      this.plugin.getLogger().info("");
      this.plugin.getLogger().info(frameColor + "────────────────────────────────────────────────────\u001b[0m");
   }

   private String formatConsoleText(String text, int maxLength) {
      if (text.length() > maxLength) {
         String var10000 = text.substring(0, maxLength - 3);
         return var10000 + "...";
      } else {
         return text + " ".repeat(maxLength - text.length());
      }
   }

   public CompletableFuture<Boolean> checkForUpdates() {
      return CompletableFuture.supplyAsync(() -> {
         try {
            URL url = new URL("https://api.modrinth.com/v2/project/sJEHxBdW/version");
            HttpURLConnection connection = (HttpURLConnection)url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("User-Agent", "CombatXT-UpdateChecker/1.0");
            if (connection.getResponseCode() != 200) {
               this.plugin.getLogger().warning("Failed to check for updates. HTTP Error: " + connection.getResponseCode());
               return false;
            } else {
               BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
               String response = (String)reader.lines().collect(Collectors.joining("\n"));
               reader.close();
               JsonArray versions = JsonParser.parseString(response).getAsJsonArray();
               if (versions.isEmpty()) {
                  return false;
               } else {
                  JsonObject latestVersionObj = null;
                  Iterator var7 = versions.iterator();

                  JsonObject version;
                  while(var7.hasNext()) {
                     JsonElement element = (JsonElement)var7.next();
                     version = element.getAsJsonObject();
                     String versionType = version.get("version_type").getAsString();
                     if (versionType.equals("release")) {
                        if (latestVersionObj == null) {
                           latestVersionObj = version;
                        } else {
                           String currentDate = latestVersionObj.get("date_published").getAsString();
                           String newDate = version.get("date_published").getAsString();
                           if (newDate.compareTo(currentDate) > 0) {
                              latestVersionObj = version;
                           }
                        }
                     }
                  }

                  if (latestVersionObj == null) {
                     return false;
                  } else {
                     this.latestVersion = latestVersionObj.get("version_number").getAsString();
                     String versionId = latestVersionObj.get("id").getAsString();
                     this.downloadUrl = "https://modrinth.com/plugin/sJEHxBdW/version/" + this.latestVersion;
                     JsonArray files = latestVersionObj.getAsJsonArray("files");
                     if (!files.isEmpty()) {
                        version = files.get(0).getAsJsonObject();
                        this.directLink = version.get("url").getAsString();
                     }

                     Version latest = new Version(this.latestVersion);
                     Version current = new Version(this.currentVersion);
                     this.updateAvailable = latest.compareTo(current) > 0;
                     return this.updateAvailable;
                  }
               }
            }
         } catch (Exception var13) {
            this.plugin.getLogger().warning("Error checking for updates: " + var13.getMessage());
            var13.printStackTrace();
            return false;
         }
      });
   }

   private void sendUpdateNotification(Player player) {
      if (this.updateAvailable && player.hasPermission("combatxt.update.notify")) {
         TextColor primaryBlue = TextColor.fromHexString("#3B82F6");
         TextColor green = TextColor.fromHexString("#22C55E");
         TextColor redPink = TextColor.fromHexString("#EF4444");
         TextColor orange = TextColor.fromHexString("#F97316");
         TextColor white = TextColor.fromHexString("#F3F4F6");
         Component borderTop = Component.text("───── CombatXT Update ─────").color(primaryBlue);
         Component borderBottom = Component.text("───────────────────────").color(primaryBlue);
         Component updateMsg = Component.text("➤ New update available!").color(green);
         Component versionsComponent = ((TextComponent)((TextComponent)((TextComponent)Component.text("✦ Current: ").color(white)).append(Component.text(this.currentVersion).color(redPink))).append(Component.text("  ✦ Latest: ").color(white))).append(Component.text(this.latestVersion).color(green));
         Component downloadButton = ((TextComponent)((TextComponent)Component.text("▶ [Click to download latest version]").color(orange)).clickEvent(ClickEvent.openUrl(this.downloadUrl))).hoverEvent(HoverEvent.showText(((TextComponent)Component.text("Download version ").color(white)).append(Component.text(this.latestVersion).color(green))));
         player.sendMessage(" ");
         player.sendMessage(borderTop);
         player.sendMessage(" ");
         player.sendMessage(updateMsg);
         player.sendMessage(versionsComponent);
         player.sendMessage(downloadButton);
         player.sendMessage(" ");
         player.sendMessage(borderBottom);
         player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8F, 1.2F);
      }

   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      if (player.hasPermission("combatxt.update.notify")) {
         UUID playerId = player.getUniqueId();
         LocalDate today = LocalDate.now();
         this.notifiedPlayers.entrySet().removeIf((entry) -> {
            return ((LocalDate)entry.getValue()).isBefore(today);
         });
         if (this.notifiedPlayers.containsKey(playerId) && ((LocalDate)this.notifiedPlayers.get(playerId)).isEqual(today)) {
            return;
         }

         if (this.updateAvailable) {
            Scheduler.runTaskLater(() -> {
               this.sendUpdateNotification(player);
               this.notifiedPlayers.put(playerId, today);
            }, 40L);
         } else {
            this.checkForUpdates().thenAccept((hasUpdate) -> {
               if (hasUpdate) {
                  Scheduler.runTask(() -> {
                     this.sendUpdateNotification(player);
                     this.notifiedPlayers.put(playerId, today);
                  });
               }

            });
         }
      }

   }
}
