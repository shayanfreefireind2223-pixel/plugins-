package dev.nighter.combatxt.updates;

import dev.nighter.combatxt.CombatXT;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class ConfigUpdater {
   private final String currentVersion;
   private final CombatXT plugin;
   private static final String CONFIG_VERSION_KEY = "config_version";

   public ConfigUpdater(CombatXT plugin) {
      this.plugin = plugin;
      this.currentVersion = plugin.getDescription().getVersion();
   }

   public void checkAndUpdateConfig() {
      File configFile = new File(this.plugin.getDataFolder(), "config.yml");
      if (!configFile.exists()) {
         this.createDefaultConfigWithHeader(configFile);
      } else {
         FileConfiguration currentConfig = YamlConfiguration.loadConfiguration(configFile);
         String configVersionStr = currentConfig.getString("config_version", "0.0.0");
         Version configVersion = new Version(configVersionStr);
         Version pluginVersion = new Version(this.currentVersion);
         if (configVersion.compareTo(pluginVersion) < 0) {
            this.plugin.debug("Updating config from version " + configVersionStr + " to " + this.currentVersion);

            try {
               Map<String, Object> userValues = this.flattenConfig(currentConfig);
               File tempFile = new File(this.plugin.getDataFolder(), "config_new.yml");
               this.createDefaultConfigWithHeader(tempFile);
               FileConfiguration newConfig = YamlConfiguration.loadConfiguration(tempFile);
               newConfig.set("config_version", this.currentVersion);
               boolean configDiffers = this.hasConfigDifferences(userValues, newConfig);
               if (configDiffers) {
                  File backupFile = new File(this.plugin.getDataFolder(), "config_backup_" + configVersionStr + ".yml");
                  Files.copy(configFile.toPath(), backupFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                  this.plugin.getLogger().info("Config backup created at " + backupFile.getName());
               } else {
                  this.plugin.debug("No significant config changes detected, skipping backup creation");
               }

               this.applyUserValues(newConfig, userValues);
               newConfig.save(configFile);
               tempFile.delete();
               this.plugin.reloadConfig();
            } catch (Exception var11) {
               this.plugin.getLogger().severe("Failed to update config: " + var11.getMessage());
               var11.printStackTrace();
            }
         }
      }

   }

   private boolean hasConfigDifferences(Map<String, Object> userValues, FileConfiguration newConfig) {
      Map<String, Object> newConfigMap = this.flattenConfig(newConfig);
      Iterator var4 = userValues.entrySet().iterator();

      while(var4.hasNext()) {
         Entry<String, Object> entry = (Entry)var4.next();
         String path = (String)entry.getKey();
         Object oldValue = entry.getValue();
         if (!path.equals("config_version")) {
            if (!newConfig.contains(path)) {
               return true;
            }

            Object newDefaultValue = newConfig.get(path);
            if (newDefaultValue != null && !newDefaultValue.equals(oldValue)) {
               return true;
            }
         }
      }

      var4 = newConfigMap.keySet().iterator();

      String path;
      do {
         if (!var4.hasNext()) {
            return false;
         }

         path = (String)var4.next();
      } while(path.equals("config_version") || userValues.containsKey(path));

      return true;
   }

   private void createDefaultConfigWithHeader(File destinationFile) {
      try {
         InputStream in = this.plugin.getResource("config.yml");

         try {
            if (in != null) {
               List<String> defaultLines = (new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))).lines().toList();
               List<String> newLines = new ArrayList();
               newLines.add("# Configuration version - Do not modify this value");
               newLines.add("config_version: " + this.currentVersion);
               newLines.add("");
               newLines.addAll(defaultLines);
               Files.write(destinationFile.toPath(), newLines, StandardCharsets.UTF_8);
            } else {
               this.plugin.getLogger().warning("Default config.yml not found in the plugin's resources.");
               destinationFile.createNewFile();
            }
         } catch (Throwable var6) {
            if (in != null) {
               try {
                  in.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (in != null) {
            in.close();
         }
      } catch (IOException var7) {
         this.plugin.getLogger().severe("Failed to create default config with header: " + var7.getMessage());
         var7.printStackTrace();
      }

   }

   private Map<String, Object> flattenConfig(ConfigurationSection config) {
      Map<String, Object> result = new HashMap();
      Iterator var3 = config.getKeys(true).iterator();

      while(var3.hasNext()) {
         String key = (String)var3.next();
         if (!config.isConfigurationSection(key)) {
            result.put(key, config.get(key));
         }
      }

      return result;
   }

   private void applyUserValues(FileConfiguration newConfig, Map<String, Object> userValues) {
      Iterator var3 = userValues.entrySet().iterator();

      while(var3.hasNext()) {
         Entry<String, Object> entry = (Entry)var3.next();
         String path = (String)entry.getKey();
         Object value = entry.getValue();
         if (!path.equals("config_version")) {
            if (newConfig.contains(path)) {
               newConfig.set(path, value);
            } else {
               this.plugin.getLogger().warning("Config path '" + path + "' from old config no longer exists in new config");
            }
         }
      }

   }
}
