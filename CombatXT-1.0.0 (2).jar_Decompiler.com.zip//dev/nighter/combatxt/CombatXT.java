package dev.nighter.combatxt;

import com.sk89q.worldguard.WorldGuard;
import dev.nighter.combatxt.bstats.Metrics;
import dev.nighter.combatxt.combat.CombatManager;
import dev.nighter.combatxt.combat.DeathAnimationManager;
import dev.nighter.combatxt.commands.CommandManager;
import dev.nighter.combatxt.configs.TimeFormatter;
import dev.nighter.combatxt.hooks.protection.GriefPreventionHook;
import dev.nighter.combatxt.hooks.protection.WorldGuardHook;
import dev.nighter.combatxt.language.LanguageManager;
import dev.nighter.combatxt.language.MessageService;
import dev.nighter.combatxt.listeners.CombatListeners;
import dev.nighter.combatxt.listeners.EnderPearlListener;
import dev.nighter.combatxt.listeners.ItemRestrictionListener;
import dev.nighter.combatxt.listeners.TridentListener;
import dev.nighter.combatxt.protection.NewbieProtectionManager;
import dev.nighter.combatxt.rewards.KillRewardManager;
import dev.nighter.combatxt.updates.ConfigUpdater;
import dev.nighter.combatxt.updates.LanguageUpdater;
import dev.nighter.combatxt.updates.UpdateChecker;
import lombok.Generated;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public final class CombatXT extends JavaPlugin {
   private static CombatXT instance;
   private final boolean debugMode = this.getConfig().getBoolean("debug", false);
   private LanguageManager languageManager;
   private MessageService messageService;
   private UpdateChecker updateChecker;
   private ConfigUpdater configUpdater;
   private LanguageUpdater languageUpdater;
   private TimeFormatter timeFormatter;
   private CommandManager commandManager;
   private CombatManager combatManager;
   private KillRewardManager killRewardManager;
   private CombatListeners combatListeners;
   private EnderPearlListener enderPearlListener;
   private TridentListener tridentListener;
   private DeathAnimationManager deathAnimationManager;
   private NewbieProtectionManager newbieProtectionManager;
   private WorldGuardHook worldGuardHook;
   private GriefPreventionHook griefPreventionHook;
   public static boolean hasWorldGuard = false;
   public static boolean hasGriefPrevention = false;

   public void onEnable() {
      long startTime = System.currentTimeMillis();
      instance = this;
      this.saveDefaultConfig();
      this.checkProtectionPlugins();
      this.languageManager = new LanguageManager(this, new LanguageManager.LanguageFileType[]{LanguageManager.LanguageFileType.MESSAGES});
      this.languageUpdater = new LanguageUpdater(this, new LanguageUpdater.LanguageFileType[]{LanguageUpdater.LanguageFileType.MESSAGES});
      this.languageUpdater.checkAndUpdateLanguageFiles();
      this.messageService = new MessageService(this, this.languageManager);
      this.updateChecker = new UpdateChecker(this);
      this.configUpdater = new ConfigUpdater(this);
      this.configUpdater.checkAndUpdateConfig();
      this.timeFormatter = new TimeFormatter(this);
      this.deathAnimationManager = new DeathAnimationManager(this);
      this.combatManager = new CombatManager(this);
      this.killRewardManager = new KillRewardManager(this);
      this.newbieProtectionManager = new NewbieProtectionManager(this);
      this.combatListeners = new CombatListeners(this);
      this.getServer().getPluginManager().registerEvents(this.combatListeners, this);
      this.enderPearlListener = new EnderPearlListener(this, this.combatManager);
      this.getServer().getPluginManager().registerEvents(this.enderPearlListener, this);
      this.tridentListener = new TridentListener(this, this.combatManager);
      this.getServer().getPluginManager().registerEvents(this.tridentListener, this);
      this.getServer().getPluginManager().registerEvents(new ItemRestrictionListener(this, this.combatManager), this);
      if (hasWorldGuard && this.getConfig().getBoolean("safezone_protection.enabled", true)) {
         this.worldGuardHook = new WorldGuardHook(this, this.combatManager);
         this.getServer().getPluginManager().registerEvents(this.worldGuardHook, this);
         this.debug("WorldGuard safezone protection enabled");
      } else if (hasWorldGuard) {
         this.getLogger().info("Found WorldGuard but safe zone barrier is disabled in config.");
      }

      if (hasGriefPrevention && this.getConfig().getBoolean("claim_protection.enabled", true)) {
         this.griefPreventionHook = new GriefPreventionHook(this, this.combatManager);
         this.getServer().getPluginManager().registerEvents(this.griefPreventionHook, this);
         this.debug("GriefPrevention claim protection enabled");
      } else if (hasGriefPrevention) {
         this.getLogger().info("Found GriefPrevention but claim protection is disabled in config.");
      }

      this.commandManager = new CommandManager(this);
      this.commandManager.registerCommands();
      this.setupBtatsMetrics();
      long loadTime = System.currentTimeMillis() - startTime;
      this.getLogger().info("CombatXT has been enabled! (Loaded in " + loadTime + "ms)");
   }

   public void onDisable() {
      if (this.combatManager != null) {
         this.combatManager.shutdown();
      }

      if (this.combatListeners != null) {
         this.combatListeners.shutdown();
      }

      if (this.enderPearlListener != null) {
         this.enderPearlListener.shutdown();
      }

      if (this.tridentListener != null) {
         this.tridentListener.shutdown();
      }

      if (this.worldGuardHook != null) {
         this.worldGuardHook.cleanup();
      }

      if (this.griefPreventionHook != null) {
         this.griefPreventionHook.cleanup();
      }

      if (this.killRewardManager != null) {
         this.killRewardManager.shutdown();
      }

      if (this.newbieProtectionManager != null) {
         this.newbieProtectionManager.shutdown();
      }

      this.getLogger().info("CombatXT has been disabled!");
   }

   private void checkProtectionPlugins() {
      hasWorldGuard = this.isPluginEnabled("WorldGuard") && this.isWorldGuardAPIAvailable();
      if (hasWorldGuard) {
         this.getLogger().info("WorldGuard integration enabled successfully!");
      }

      hasGriefPrevention = this.isPluginEnabled("GriefPrevention") && this.isGriefPreventionAPIAvailable();
      if (hasGriefPrevention) {
         this.getLogger().info("GriefPrevention integration enabled successfully!");
      }

   }

   private boolean isPluginEnabled(String pluginName) {
      Plugin plugin = this.getServer().getPluginManager().getPlugin(pluginName);
      return plugin != null && plugin.isEnabled();
   }

   private boolean isWorldGuardAPIAvailable() {
      try {
         Class.forName("com.sk89q.worldguard.WorldGuard");
         return WorldGuard.getInstance() != null;
      } catch (ClassNotFoundException | NoClassDefFoundError var2) {
         return false;
      }
   }

   private boolean isGriefPreventionAPIAvailable() {
      try {
         Class.forName("me.ryanhamshire.GriefPrevention.GriefPrevention");
         return true;
      } catch (ClassNotFoundException | NoClassDefFoundError var2) {
         return false;
      }
   }

   private void setupBtatsMetrics() {
      Scheduler.runTask(() -> {
         new Metrics(this, 25387);
      });
   }

   public long getTimeFromConfig(String path, String defaultValue) {
      return this.timeFormatter.getTimeFromConfig(path, defaultValue);
   }

   public long getTimeFromConfigInMilliseconds(String path, String defaultValue) {
      long ticks = this.timeFormatter.getTimeFromConfig(path, defaultValue);
      return ticks * 50L;
   }

   public void refreshTimeCache() {
      if (this.timeFormatter != null) {
         this.timeFormatter.clearCache();
      }

   }

   public void debug(String message) {
      if (this.debugMode) {
         this.getLogger().info("[DEBUG] " + message);
      }

   }

   public void reload() {
      if (this.worldGuardHook != null) {
         this.worldGuardHook.cleanup();
      }

      if (this.griefPreventionHook != null) {
         this.griefPreventionHook.cleanup();
      }

   }

   @Generated
   public boolean isDebugMode() {
      return this.debugMode;
   }

   @Generated
   public LanguageManager getLanguageManager() {
      return this.languageManager;
   }

   @Generated
   public MessageService getMessageService() {
      return this.messageService;
   }

   @Generated
   public UpdateChecker getUpdateChecker() {
      return this.updateChecker;
   }

   @Generated
   public ConfigUpdater getConfigUpdater() {
      return this.configUpdater;
   }

   @Generated
   public LanguageUpdater getLanguageUpdater() {
      return this.languageUpdater;
   }

   @Generated
   public TimeFormatter getTimeFormatter() {
      return this.timeFormatter;
   }

   @Generated
   public CommandManager getCommandManager() {
      return this.commandManager;
   }

   @Generated
   public CombatManager getCombatManager() {
      return this.combatManager;
   }

   @Generated
   public KillRewardManager getKillRewardManager() {
      return this.killRewardManager;
   }

   @Generated
   public CombatListeners getCombatListeners() {
      return this.combatListeners;
   }

   @Generated
   public EnderPearlListener getEnderPearlListener() {
      return this.enderPearlListener;
   }

   @Generated
   public TridentListener getTridentListener() {
      return this.tridentListener;
   }

   @Generated
   public DeathAnimationManager getDeathAnimationManager() {
      return this.deathAnimationManager;
   }

   @Generated
   public NewbieProtectionManager getNewbieProtectionManager() {
      return this.newbieProtectionManager;
   }

   @Generated
   public WorldGuardHook getWorldGuardHook() {
      return this.worldGuardHook;
   }

   @Generated
   public GriefPreventionHook getGriefPreventionHook() {
      return this.griefPreventionHook;
   }

   @Generated
   public static CombatXT getInstance() {
      return instance;
   }
}
