package dev.nighter.combatxt.rewards;

import dev.nighter.combatxt.CombatXT;
import dev.nighter.combatxt.Scheduler;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;
import lombok.Generated;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class KillRewardManager {
   private final CombatXT plugin;
   private final File cooldownFile;
   private FileConfiguration cooldownConfig;
   private final Map<String, Long> killRewardCooldowns = new ConcurrentHashMap();
   private boolean enabled;
   private List<String> rewardCommands;
   private boolean useGlobalCooldown;
   private boolean useSamePlayerCooldown;
   private long globalCooldownDuration;
   private long samePlayerCooldownDuration;
   private Scheduler.Task cleanupTask;
   private Scheduler.Task saveTask;
   private static final long CLEANUP_INTERVAL = 12000L;
   private static final long SAVE_INTERVAL = 6000L;
   private static final String GLOBAL_COOLDOWN_PREFIX = "global:";
   private static final String PLAYER_COOLDOWN_PREFIX = "player:";

   public KillRewardManager(CombatXT plugin) {
      this.plugin = plugin;
      this.cooldownFile = new File(plugin.getDataFolder(), "kill_cooldowns_data.yml");
      this.loadConfig();
      this.loadCooldownData();
      this.startCleanupTask();
      this.startAutoSaveTask();
   }

   public void loadConfig() {
      FileConfiguration config = this.plugin.getConfig();
      this.enabled = config.getBoolean("kill_rewards.enabled", true);
      this.rewardCommands = config.getStringList("kill_rewards.commands");
      this.useGlobalCooldown = config.getBoolean("kill_rewards.cooldown.use_global_cooldown", false);
      this.useSamePlayerCooldown = config.getBoolean("kill_rewards.cooldown.use_same_player_cooldown", true);
      this.globalCooldownDuration = this.plugin.getTimeFromConfigInMilliseconds("kill_rewards.cooldown.duration", "1d");
      this.samePlayerCooldownDuration = this.plugin.getTimeFromConfigInMilliseconds("kill_rewards.cooldown.same_player_duration", "1d");
      this.plugin.debug("KillRewardManager config loaded - Enabled: " + this.enabled + ", Global cooldown: " + this.useGlobalCooldown + ", Same player cooldown: " + this.useSamePlayerCooldown);
   }

   private void loadCooldownData() {
      if (!this.cooldownFile.exists()) {
         try {
            this.cooldownFile.getParentFile().mkdirs();
            this.cooldownFile.createNewFile();
            this.plugin.debug("Created new kill_cooldowns_data.yml file");
         } catch (IOException var8) {
            this.plugin.getLogger().severe("Failed to create kill_cooldowns_data.yml: " + var8.getMessage());
            return;
         }
      }

      this.cooldownConfig = YamlConfiguration.loadConfiguration(this.cooldownFile);
      int loadedCount = 0;
      long currentTime = System.currentTimeMillis();
      Iterator var4 = this.cooldownConfig.getKeys(false).iterator();

      while(var4.hasNext()) {
         String key = (String)var4.next();
         long expirationTime = this.cooldownConfig.getLong(key);
         if (expirationTime > currentTime) {
            this.killRewardCooldowns.put(key, expirationTime);
            ++loadedCount;
         }
      }

      this.plugin.getLogger().info("Loaded " + loadedCount + " active kill reward cooldowns");
   }

   public void saveCooldownData() {
      this.saveCooldownData(false);
   }

   public void saveCooldownData(boolean synchronous) {
      if (this.cooldownConfig == null) {
         this.cooldownConfig = new YamlConfiguration();
      }

      Iterator var2 = this.cooldownConfig.getKeys(false).iterator();

      while(var2.hasNext()) {
         String key = (String)var2.next();
         this.cooldownConfig.set(key, (Object)null);
      }

      long currentTime = System.currentTimeMillis();
      Iterator var5 = this.killRewardCooldowns.entrySet().iterator();

      while(var5.hasNext()) {
         Entry<String, Long> entry = (Entry)var5.next();
         if ((Long)entry.getValue() > currentTime) {
            this.cooldownConfig.set((String)entry.getKey(), entry.getValue());
         }
      }

      if (!synchronous && this.plugin.isEnabled()) {
         Scheduler.runTaskAsync(() -> {
            try {
               this.cooldownConfig.save(this.cooldownFile);
               this.plugin.debug("Saved kill reward cooldowns to file");
            } catch (IOException var2) {
               this.plugin.getLogger().severe("Failed to save kill_cooldowns_data.yml: " + var2.getMessage());
            }

         });
      } else {
         try {
            this.cooldownConfig.save(this.cooldownFile);
            this.plugin.debug("Saved kill reward cooldowns to file (synchronous)");
         } catch (IOException var7) {
            this.plugin.getLogger().severe("Failed to save kill_cooldowns_data.yml: " + var7.getMessage());
         }
      }

   }

   public boolean isOnCooldown(Player killer, Player victim) {
      if (this.enabled && killer != null) {
         long currentTime = System.currentTimeMillis();
         String playerKey;
         Long cooldownEnd;
         if (this.useGlobalCooldown) {
            playerKey = "global:" + String.valueOf(killer.getUniqueId());
            cooldownEnd = (Long)this.killRewardCooldowns.get(playerKey);
            return cooldownEnd != null && currentTime < cooldownEnd;
         } else if (this.useSamePlayerCooldown && victim != null) {
            String var10000 = String.valueOf(killer.getUniqueId());
            playerKey = "player:" + var10000 + ":" + String.valueOf(victim.getUniqueId());
            cooldownEnd = (Long)this.killRewardCooldowns.get(playerKey);
            return cooldownEnd != null && currentTime < cooldownEnd;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public void setCooldown(Player killer, Player victim) {
      if (this.enabled && killer != null) {
         long currentTime = System.currentTimeMillis();
         CombatXT var10000;
         String var10001;
         String playerKey;
         long expirationTime;
         if (this.useGlobalCooldown) {
            playerKey = "global:" + String.valueOf(killer.getUniqueId());
            expirationTime = currentTime + this.globalCooldownDuration;
            this.killRewardCooldowns.put(playerKey, expirationTime);
            var10000 = this.plugin;
            var10001 = killer.getName();
            var10000.debug("Set global kill reward cooldown for " + var10001 + " until " + String.valueOf(new Date(expirationTime)));
         } else if (this.useSamePlayerCooldown && victim != null) {
            String var8 = String.valueOf(killer.getUniqueId());
            playerKey = "player:" + var8 + ":" + String.valueOf(victim.getUniqueId());
            expirationTime = currentTime + this.samePlayerCooldownDuration;
            this.killRewardCooldowns.put(playerKey, expirationTime);
            var10000 = this.plugin;
            var10001 = killer.getName();
            var10000.debug("Set same-player kill reward cooldown for " + var10001 + " -> " + victim.getName() + " until " + String.valueOf(new Date(expirationTime)));
         }
      }

   }

   private void executeRewardCommands(Player killer, Player victim) {
      if (this.rewardCommands != null && !this.rewardCommands.isEmpty()) {
         AtomicBoolean anyCommandSuccessful = new AtomicBoolean(false);
         Scheduler.runTask(() -> {
            Iterator var4 = this.rewardCommands.iterator();

            while(var4.hasNext()) {
               String command = (String)var4.next();
               String processedCommand = command.replace("%killer%", killer.getName()).replace("%victim%", victim.getName());

               try {
                  Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processedCommand);
                  this.plugin.debug("Executed kill reward command: " + processedCommand);
                  anyCommandSuccessful.set(true);
               } catch (Exception var8) {
                  this.plugin.getLogger().warning("Failed to execute kill reward command '" + processedCommand + "': " + var8.getMessage());
               }
            }

            if (anyCommandSuccessful.get()) {
               this.sendKillRewardMessage(killer, victim);
            }

         });
      }

   }

   private void sendKillRewardMessage(Player killer, Player victim) {
      if (killer != null && killer.isOnline()) {
         try {
            Map<String, String> placeholders = new HashMap();
            placeholders.put("killer", killer.getName());
            placeholders.put("victim", victim != null ? victim.getName() : "Unknown");
            this.plugin.getMessageService().sendMessage((Player)killer, "kill_reward_received", placeholders);
            this.plugin.debug("Sent kill reward message to " + killer.getName());
         } catch (Exception var6) {
            Logger var10000 = this.plugin.getLogger();
            String var10001 = killer.getName();
            var10000.warning("Failed to send kill reward message to " + var10001 + ": " + var6.getMessage());
         }
      }

   }

   public void giveKillReward(Player killer, Player victim) {
      if (this.enabled && killer != null && victim != null && !killer.equals(victim)) {
         String var3;
         CombatXT var10000;
         if (this.isOnCooldown(killer, victim)) {
            var10000 = this.plugin;
            var3 = killer.getName();
            var10000.debug("Kill reward cooldown active for " + var3 + " -> " + victim.getName());
         } else {
            var10000 = this.plugin;
            var3 = killer.getName();
            var10000.debug("Processing kill reward for " + var3 + " -> " + victim.getName());
            this.setCooldown(killer, victim);
            this.executeRewardCommands(killer, victim);
         }
      } else {
         boolean var10001 = this.enabled;
         this.plugin.debug("Kill reward skipped - enabled: " + var10001 + ", killer: " + (killer != null ? killer.getName() : "null") + ", victim: " + (victim != null ? victim.getName() : "null") + ", same player: " + (killer != null && killer.equals(victim)));
      }

   }

   public long getRemainingCooldown(Player killer, Player victim) {
      if (this.enabled && killer != null) {
         long currentTime = System.currentTimeMillis();
         Long cooldownEnd = null;
         String playerKey;
         if (this.useGlobalCooldown) {
            playerKey = "global:" + String.valueOf(killer.getUniqueId());
            cooldownEnd = (Long)this.killRewardCooldowns.get(playerKey);
         } else if (this.useSamePlayerCooldown && victim != null) {
            String var10000 = String.valueOf(killer.getUniqueId());
            playerKey = "player:" + var10000 + ":" + String.valueOf(victim.getUniqueId());
            cooldownEnd = (Long)this.killRewardCooldowns.get(playerKey);
         }

         return cooldownEnd != null && currentTime < cooldownEnd ? cooldownEnd - currentTime : 0L;
      } else {
         return 0L;
      }
   }

   private void startCleanupTask() {
      if (this.cleanupTask != null) {
         this.cleanupTask.cancel();
      }

      this.cleanupTask = Scheduler.runTaskTimerAsync(() -> {
         long currentTime = System.currentTimeMillis();
         int removedCount = 0;
         Iterator iterator = this.killRewardCooldowns.entrySet().iterator();

         while(iterator.hasNext()) {
            Entry<String, Long> entry = (Entry)iterator.next();
            if (currentTime >= (Long)entry.getValue()) {
               iterator.remove();
               ++removedCount;
            }
         }

         if (removedCount > 0) {
            this.plugin.debug("Cleaned up " + removedCount + " expired kill reward cooldowns");
         }

      }, 12000L, 12000L);
   }

   private void startAutoSaveTask() {
      if (this.saveTask != null) {
         this.saveTask.cancel();
      }

      this.saveTask = Scheduler.runTaskTimerAsync(this::saveCooldownData, 6000L, 6000L);
   }

   public void clearPlayerCooldowns(Player player) {
      if (player != null) {
         String playerUUID = player.getUniqueId().toString();
         this.killRewardCooldowns.entrySet().removeIf((entry) -> {
            return ((String)entry.getKey()).contains(playerUUID);
         });
         this.plugin.debug("Cleared all kill reward cooldowns for " + player.getName());
      }

   }

   public void shutdown() {
      if (this.cleanupTask != null) {
         this.cleanupTask.cancel();
         this.cleanupTask = null;
      }

      if (this.saveTask != null) {
         this.saveTask.cancel();
         this.saveTask = null;
      }

      this.saveCooldownData(true);
      this.killRewardCooldowns.clear();
   }

   @Generated
   public Map<String, Long> getKillRewardCooldowns() {
      return this.killRewardCooldowns;
   }
}
