package dev.nighter.combatxt.language;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.Generated;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class MessageService {
   private final JavaPlugin plugin;
   private final LanguageManager languageManager;
   private static final Map<String, String> EMPTY_PLACEHOLDERS = Collections.emptyMap();
   private final Map<String, Boolean> keyExistsCache = new ConcurrentHashMap(128);

   public void sendMessage(CommandSender sender, String key) {
      this.sendMessage(sender, key, EMPTY_PLACEHOLDERS);
   }

   public void sendMessage(Player player, String key) {
      this.sendMessage(player, key, EMPTY_PLACEHOLDERS);
   }

   public void sendMessage(Player player, String key, Map<String, String> placeholders) {
      this.sendMessage((CommandSender)player, key, placeholders);
   }

   public void sendMessage(CommandSender sender, String key, Map<String, String> placeholders) {
      if (!this.checkKeyExists(key)) {
         this.plugin.getLogger().warning("Message key not found: " + key);
         sender.sendMessage("§cMissing message key: " + key);
      } else {
         String message = this.languageManager.getMessage(key, placeholders);
         if (message != null && !message.startsWith("Missing message:")) {
            sender.sendMessage(message);
         }

         if (sender instanceof Player) {
            Player player = (Player)sender;
            this.sendPlayerSpecificContent(player, key, placeholders);
         }
      }

   }

   private boolean checkKeyExists(String key) {
      return (Boolean)this.keyExistsCache.computeIfAbsent(key, (k) -> {
         return this.languageManager.keyExists(k);
      });
   }

   public void clearKeyExistsCache() {
      this.keyExistsCache.clear();
   }

   public void sendConsoleMessage(String key) {
      this.sendConsoleMessage(key, EMPTY_PLACEHOLDERS);
   }

   public void sendConsoleMessage(String key, Map<String, String> placeholders) {
      if (!this.languageManager.keyExists(key)) {
         this.plugin.getLogger().warning("Message key not found: " + key);
         this.plugin.getLogger().warning("§cMissing message key: " + key);
      } else {
         String message = this.languageManager.getRawMessage(key, placeholders);
         if (message != null && !message.startsWith("Missing message:")) {
            String consoleMessage = this.stripColorCodes(message);
            this.plugin.getLogger().info(consoleMessage);
         }
      }

   }

   private String stripColorCodes(String message) {
      return message.replaceAll("§[0-9a-fA-Fk-oK-OrR]", "").replaceAll("&#[0-9a-fA-F]{6}", "").replaceAll("&[0-9a-fA-Fk-oK-OrR]", "");
   }

   private void sendPlayerSpecificContent(Player player, String key, Map<String, String> placeholders) {
      String title = this.languageManager.getTitle(key, placeholders);
      String subtitle = this.languageManager.getSubtitle(key, placeholders);
      if (title != null || subtitle != null) {
         player.sendTitle(title != null ? title : "", subtitle != null ? subtitle : "", 10, 70, 20);
      }

      String actionBar = this.languageManager.getActionBar(key, placeholders);
      if (actionBar != null) {
         player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(actionBar));
      }

      String soundName = this.languageManager.getSound(key);
      if (soundName != null) {
         try {
            player.playSound(player.getLocation(), soundName, 1.0F, 1.0F);
         } catch (Exception var9) {
            this.plugin.getLogger().warning("Invalid sound name for key " + key + ": " + soundName);
         }
      }

   }

   @Generated
   public MessageService(JavaPlugin plugin, LanguageManager languageManager) {
      this.plugin = plugin;
      this.languageManager = languageManager;
   }
}
