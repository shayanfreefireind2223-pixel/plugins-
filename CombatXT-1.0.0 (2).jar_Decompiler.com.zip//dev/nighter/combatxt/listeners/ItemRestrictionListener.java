package dev.nighter.combatxt.listeners;

import dev.nighter.combatxt.CombatXT;
import dev.nighter.combatxt.combat.CombatManager;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Generated;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;

public class ItemRestrictionListener implements Listener {
   private final CombatXT plugin;
   private final CombatManager combatManager;

   public static String formatItemName(Material material) {
      if (material == null) {
         return "Unknown Item";
      } else {
         String[] words = material.name().split("_");
         StringBuilder formattedName = new StringBuilder();
         String[] var3 = words;
         int var4 = words.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            String word = var3[var5];
            formattedName.append(word.substring(0, 1).toUpperCase()).append(word.substring(1).toLowerCase()).append(" ");
         }

         return formattedName.toString().trim();
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
      if (this.plugin.getConfig().getBoolean("combat.item_restrictions.enabled", true)) {
         Player player = event.getPlayer();
         ItemStack item = event.getItem();
         if (this.combatManager.isInCombat(player)) {
            List<String> disabledItems = this.plugin.getConfig().getStringList("combat.item_restrictions.disabled_items");
            if (this.isItemDisabled(item.getType(), disabledItems)) {
               event.setCancelled(true);
               Map<String, String> placeholders = new HashMap();
               placeholders.put("player", player.getName());
               placeholders.put("item", formatItemName(item.getType()));
               this.plugin.getMessageService().sendMessage((Player)player, "item_use_blocked_in_combat", placeholders);
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onPlayerMoveEvent(PlayerMoveEvent event) {
      if (this.plugin.getConfig().getBoolean("combat.item_restrictions.enabled", true)) {
         Player player = event.getPlayer();
         if (this.combatManager.isInCombat(player)) {
            List<String> disabledItems = this.plugin.getConfig().getStringList("combat.item_restrictions.disabled_items");
            if (disabledItems.contains("ELYTRA") && player.isGliding()) {
               player.setGliding(false);
               Map<String, String> placeholders = new HashMap();
               placeholders.put("player", player.getName());
               placeholders.put("item", "Elytra");
               this.plugin.getMessageService().sendMessage((Player)player, "item_use_blocked_in_combat", placeholders);
            }
         }
      }

   }

   private boolean isItemDisabled(Material itemType, List<String> disabledItems) {
      return disabledItems.stream().anyMatch((disabledItem) -> {
         return itemType.name().equalsIgnoreCase(disabledItem) || itemType.name().contains(disabledItem);
      });
   }

   @Generated
   public ItemRestrictionListener(CombatXT plugin, CombatManager combatManager) {
      this.plugin = plugin;
      this.combatManager = combatManager;
   }
}
