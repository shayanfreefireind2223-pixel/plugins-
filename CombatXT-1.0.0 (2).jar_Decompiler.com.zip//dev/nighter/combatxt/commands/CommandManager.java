package dev.nighter.combatxt.commands;

import dev.nighter.combatxt.CombatXT;
import dev.nighter.combatxt.commands.subcommands.HelpCommand;
import dev.nighter.combatxt.commands.subcommands.KillRewardCommand;
import dev.nighter.combatxt.commands.subcommands.NewbieProtectionCommand;
import dev.nighter.combatxt.commands.subcommands.ReloadCommand;
import dev.nighter.combatxt.commands.subcommands.RemoveTagCommand;
import dev.nighter.combatxt.commands.subcommands.TagCommand;
import java.util.HashMap;
import java.util.Map;
import lombok.Generated;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;

public class CommandManager implements CommandExecutor {
   private final CombatXT plugin;
   private final Map<String, BaseCommand> commands = new HashMap();
   private final TabCompleter tabCompleter;

   public CommandManager(CombatXT plugin) {
      this.plugin = plugin;
      this.tabCompleter = new TabCompleter(this);
   }

   public void registerCommands() {
      this.registerCommand("reload", new ReloadCommand(this.plugin));
      this.registerCommand("tag", new TagCommand(this.plugin));
      this.registerCommand("help", new HelpCommand(this.plugin));
      this.registerCommand("removeTag", new RemoveTagCommand(this.plugin));
      this.registerCommand("killReward", new KillRewardCommand(this.plugin));
      this.registerCommand("newbieProtection", new NewbieProtectionCommand(this.plugin));
      PluginCommand mainCommand = this.plugin.getCommand("combatxt");
      if (mainCommand != null) {
         mainCommand.setExecutor(this);
         mainCommand.setTabCompleter(this.tabCompleter);
      }

   }

   private void registerCommand(String name, BaseCommand command) {
      this.commands.put(name, command);
   }

   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
      if (args.length == 0) {
         ((BaseCommand)this.commands.get("help")).execute(sender, args);
         return true;
      } else {
         String subCommand = args[0];
         BaseCommand command = (BaseCommand)this.commands.get(subCommand);
         if (command == null) {
            ((BaseCommand)this.commands.get("help")).execute(sender, args);
            return true;
         } else {
            String[] subArgs = new String[args.length - 1];
            System.arraycopy(args, 1, subArgs, 0, args.length - 1);
            return command.execute(sender, subArgs);
         }
      }
   }

   @Generated
   public Map<String, BaseCommand> getCommands() {
      return this.commands;
   }
}
