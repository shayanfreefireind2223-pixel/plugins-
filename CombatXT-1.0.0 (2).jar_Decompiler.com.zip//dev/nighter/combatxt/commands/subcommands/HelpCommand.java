package dev.nighter.combatxt.commands.subcommands;

import dev.nighter.combatxt.CombatXT;
import dev.nighter.combatxt.commands.BaseCommand;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.CommandSender;

public class HelpCommand extends BaseCommand {
   public HelpCommand(CombatXT plugin) {
      super(plugin);
   }

   public boolean execute(CommandSender sender, String[] args) {
      if (!this.checkSender(sender)) {
         return true;
      } else {
         this.messageService.sendMessage(sender, "help_message");
         return true;
      }
   }

   public String getPermission() {
      return "combatxt.command.use";
   }

   public boolean isPlayerOnly() {
      return false;
   }

   public List<String> tabComplete(CommandSender sender, String[] args) {
      return new ArrayList();
   }
}
