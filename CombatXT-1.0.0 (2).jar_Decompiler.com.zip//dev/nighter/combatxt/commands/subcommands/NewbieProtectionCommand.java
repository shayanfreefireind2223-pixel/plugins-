package dev.nighter.combatxt.commands.subcommands;

import dev.nighter.combatxt.CombatXT;
import dev.nighter.combatxt.commands.BaseCommand;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NewbieProtectionCommand extends BaseCommand {
   public NewbieProtectionCommand(CombatXT plugin) {
      super(plugin);
   }

   public boolean execute(CommandSender sender, String[] args) {
      if (!this.checkSender(sender)) {
         return true;
      } else if (args.length == 0) {
         this.sendUsage(sender);
         return true;
      } else {
         String subCommand = args[0];
         String[] subArgs = (String[])Arrays.copyOfRange(args, 1, args.length);
         String var5 = subCommand.toLowerCase();
         byte var6 = -1;
         switch(var5.hashCode()) {
         case -934610812:
            if (var5.equals("remove")) {
               var6 = 1;
            }
            break;
         case 3173137:
            if (var5.equals("give")) {
               var6 = 0;
            }
            break;
         case 94627080:
            if (var5.equals("check")) {
               var6 = 2;
            }
         }

         switch(var6) {
         case 0:
            return this.executeGive(sender, subArgs);
         case 1:
            return this.executeRemove(sender, subArgs);
         case 2:
            return this.executeCheck(sender, subArgs);
         default:
            this.sendUsage(sender);
            return true;
         }
      }
   }

   private boolean executeGive(CommandSender sender, String[] args) {
      Map<String, String> placeholders = new HashMap();
      if (args.length != 1) {
         sender.sendMessage("§cUsage: /combatxt newbieProtection give <player>");
         return true;
      } else {
         Player target = Bukkit.getPlayer(args[0]);
         if (target == null) {
            placeholders.put("player", args[0]);
            this.messageService.sendMessage((CommandSender)sender, "player_not_found", placeholders);
            return true;
         } else if (this.plugin.getNewbieProtectionManager().hasProtection(target)) {
            placeholders.put("player", target.getName());
            this.messageService.sendMessage((CommandSender)sender, "newbie_protection_already_has", placeholders);
            return true;
         } else {
            this.plugin.getNewbieProtectionManager().grantProtection(target);
            placeholders.put("player", target.getName());
            this.messageService.sendMessage((CommandSender)sender, "newbie_protection_give_success", placeholders);
            return true;
         }
      }
   }

   private boolean executeRemove(CommandSender sender, String[] args) {
      Map<String, String> placeholders = new HashMap();
      if (args.length != 1) {
         sender.sendMessage("§cUsage: /combatxt newbieProtection remove <player>");
         return true;
      } else {
         Player target = Bukkit.getPlayer(args[0]);
         if (target == null) {
            placeholders.put("player", args[0]);
            this.messageService.sendMessage((CommandSender)sender, "player_not_found", placeholders);
            return true;
         } else if (!this.plugin.getNewbieProtectionManager().hasProtection(target)) {
            placeholders.put("player", target.getName());
            this.messageService.sendMessage((CommandSender)sender, "newbie_protection_not_protected", placeholders);
            return true;
         } else {
            this.plugin.getNewbieProtectionManager().removeProtection(target, false);
            placeholders.put("player", target.getName());
            this.messageService.sendMessage((CommandSender)sender, "newbie_protection_remove_success", placeholders);
            return true;
         }
      }
   }

   private boolean executeCheck(CommandSender sender, String[] args) {
      Map<String, String> placeholders = new HashMap();
      if (args.length != 1) {
         sender.sendMessage("§cUsage: /combatxt newbieProtection check <player>");
         return true;
      } else {
         Player target = Bukkit.getPlayer(args[0]);
         if (target == null) {
            placeholders.put("player", args[0]);
            this.messageService.sendMessage((CommandSender)sender, "player_not_found", placeholders);
            return true;
         } else if (!this.plugin.getNewbieProtectionManager().hasProtection(target)) {
            placeholders.put("player", target.getName());
            this.messageService.sendMessage((CommandSender)sender, "newbie_protection_not_protected", placeholders);
            return true;
         } else {
            long remainingTime = this.plugin.getNewbieProtectionManager().getRemainingTime(target);
            String formattedTime = this.formatTime(remainingTime);
            placeholders.put("player", target.getName());
            placeholders.put("time", formattedTime);
            this.messageService.sendMessage((CommandSender)sender, "newbie_protection_check_protected", placeholders);
            return true;
         }
      }
   }

   private void sendUsage(CommandSender sender) {
      sender.sendMessage("§cUsage:");
      sender.sendMessage("§c/combatxt newbieProtection give <player>");
      sender.sendMessage("§c/combatxt newbieProtection remove <player>");
      sender.sendMessage("§c/combatxt newbieProtection check <player>");
   }

   private String formatTime(long seconds) {
      if (seconds <= 0L) {
         return "0s";
      } else {
         long hours = seconds / 3600L;
         long minutes = seconds % 3600L / 60L;
         long secs = seconds % 60L;
         StringBuilder sb = new StringBuilder();
         if (hours > 0L) {
            sb.append(hours).append("h ");
         }

         if (minutes > 0L) {
            sb.append(minutes).append("m ");
         }

         if (secs > 0L || sb.length() == 0) {
            sb.append(secs).append("s");
         }

         return sb.toString().trim();
      }
   }

   public String getPermission() {
      return "combatxt.command.use";
   }

   public boolean isPlayerOnly() {
      return false;
   }

   public List<String> tabComplete(CommandSender sender, String[] args) {
      if (args.length == 1) {
         return (List)Arrays.asList("give", "remove", "check").stream().filter((cmd) -> {
            return cmd.toLowerCase().startsWith(args[0].toLowerCase());
         }).collect(Collectors.toList());
      } else {
         return args.length == 2 ? (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).filter((name) -> {
            return name.toLowerCase().startsWith(args[1].toLowerCase());
         }).collect(Collectors.toList()) : super.tabComplete(sender, args);
      }
   }
}
