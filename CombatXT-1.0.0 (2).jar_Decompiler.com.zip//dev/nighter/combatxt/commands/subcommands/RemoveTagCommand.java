package dev.nighter.combatxt.commands.subcommands;

import dev.nighter.combatxt.CombatXT;
import dev.nighter.combatxt.commands.BaseCommand;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.generator.WorldInfo;

public class RemoveTagCommand extends BaseCommand {
   public RemoveTagCommand(CombatXT plugin) {
      super(plugin);
   }

   public boolean execute(CommandSender sender, String[] args) {
      if (!this.checkSender(sender)) {
         return true;
      } else if (args.length == 0) {
         this.sendUsage(sender);
         return true;
      } else {
         String subCommand = args[0].toLowerCase();
         String[] subArgs = (String[])Arrays.copyOfRange(args, 1, args.length);
         byte var6 = -1;
         switch(subCommand.hashCode()) {
         case -985752863:
            if (subCommand.equals("player")) {
               var6 = 0;
            }
            break;
         case 96673:
            if (subCommand.equals("all")) {
               var6 = 2;
            }
            break;
         case 113318802:
            if (subCommand.equals("world")) {
               var6 = 1;
            }
         }

         switch(var6) {
         case 0:
            return this.executeRemovePlayer(sender, subArgs);
         case 1:
            return this.executeRemoveWorld(sender, subArgs);
         case 2:
            return this.executeRemoveAll(sender, subArgs);
         default:
            this.sendUsage(sender);
            return true;
         }
      }
   }

   private boolean executeRemovePlayer(CommandSender sender, String[] args) {
      Map<String, String> placeholders = new HashMap();
      if (args.length != 1) {
         sender.sendMessage("§cUsage: /combatxt removeTag player <player>");
         return true;
      } else {
         Player target = Bukkit.getPlayer(args[0]);
         if (target == null) {
            placeholders.put("player", args[0]);
            this.messageService.sendMessage((CommandSender)sender, "player_not_found", placeholders);
            return true;
         } else if (!this.plugin.getCombatManager().isInCombat(target)) {
            placeholders.put("player", target.getName());
            this.messageService.sendMessage((CommandSender)sender, "player_not_in_combat", placeholders);
            return true;
         } else {
            this.plugin.getCombatManager().removeFromCombatSilently(target);
            placeholders.put("player", target.getName());
            this.messageService.sendMessage((CommandSender)sender, "combat_remove_success", placeholders);
            return true;
         }
      }
   }

   private boolean executeRemoveWorld(CommandSender sender, String[] args) {
      Map<String, String> placeholders = new HashMap();
      if (args.length != 1) {
         sender.sendMessage("§cUsage: /combatxt removeTag world <world>");
         return true;
      } else {
         World targetWorld = Bukkit.getWorld(args[0]);
         if (targetWorld == null) {
            placeholders.put("world", args[0]);
            this.messageService.sendMessage((CommandSender)sender, "world_not_found", placeholders);
            return true;
         } else {
            List<Player> playersInCombat = (List)Bukkit.getOnlinePlayers().stream().filter((playerx) -> {
               return playerx.getWorld().equals(targetWorld);
            }).filter((playerx) -> {
               return this.plugin.getCombatManager().isInCombat(playerx);
            }).collect(Collectors.toList());
            if (playersInCombat.isEmpty()) {
               placeholders.put("world", targetWorld.getName());
               this.messageService.sendMessage((CommandSender)sender, "no_players_in_combat_world", placeholders);
               return true;
            } else {
               int removedCount = 0;

               for(Iterator var7 = playersInCombat.iterator(); var7.hasNext(); ++removedCount) {
                  Player player = (Player)var7.next();
                  this.plugin.getCombatManager().removeFromCombatSilently(player);
               }

               placeholders.put("world", targetWorld.getName());
               placeholders.put("count", String.valueOf(removedCount));
               this.messageService.sendMessage((CommandSender)sender, "combat_remove_world_success", placeholders);
               return true;
            }
         }
      }
   }

   private boolean executeRemoveAll(CommandSender sender, String[] args) {
      Map<String, String> placeholders = new HashMap();
      if (args.length != 0) {
         sender.sendMessage("§cUsage: /combatxt removeTag all");
         return true;
      } else {
         List<Player> playersInCombat = (List)Bukkit.getOnlinePlayers().stream().filter((playerx) -> {
            return this.plugin.getCombatManager().isInCombat(playerx);
         }).collect(Collectors.toList());
         if (playersInCombat.isEmpty()) {
            this.messageService.sendMessage((CommandSender)sender, "no_players_in_combat_server", placeholders);
            return true;
         } else {
            int removedCount = 0;

            for(Iterator var6 = playersInCombat.iterator(); var6.hasNext(); ++removedCount) {
               Player player = (Player)var6.next();
               this.plugin.getCombatManager().removeFromCombatSilently(player);
            }

            placeholders.put("count", String.valueOf(removedCount));
            this.messageService.sendMessage((CommandSender)sender, "combat_remove_all_success", placeholders);
            return true;
         }
      }
   }

   private void sendUsage(CommandSender sender) {
      sender.sendMessage("§cUsage:");
      sender.sendMessage("§c/combatxt removeTag player <player>");
      sender.sendMessage("§c/combatxt removeTag world <world>");
      sender.sendMessage("§c/combatxt removeTag all");
   }

   public String getPermission() {
      return "combatxt.command.use";
   }

   public boolean isPlayerOnly() {
      return false;
   }

   public List<String> tabComplete(CommandSender sender, String[] args) {
      if (args.length == 1) {
         return (List)Arrays.asList("player", "world", "all").stream().filter((cmd) -> {
            return cmd.toLowerCase().startsWith(args[0].toLowerCase());
         }).collect(Collectors.toList());
      } else {
         if (args.length == 2) {
            String subCommand = args[0].toLowerCase();
            byte var5 = -1;
            switch(subCommand.hashCode()) {
            case -985752863:
               if (subCommand.equals("player")) {
                  var5 = 0;
               }
               break;
            case 96673:
               if (subCommand.equals("all")) {
                  var5 = 2;
               }
               break;
            case 113318802:
               if (subCommand.equals("world")) {
                  var5 = 1;
               }
            }

            switch(var5) {
            case 0:
               return (List)Bukkit.getOnlinePlayers().stream().filter((player) -> {
                  return this.plugin.getCombatManager().isInCombat(player);
               }).map(Player::getName).filter((name) -> {
                  return name.toLowerCase().startsWith(args[1].toLowerCase());
               }).collect(Collectors.toList());
            case 1:
               return (List)Bukkit.getWorlds().stream().map(WorldInfo::getName).filter((name) -> {
                  return name.toLowerCase().startsWith(args[1].toLowerCase());
               }).collect(Collectors.toList());
            case 2:
            }
         }

         return super.tabComplete(sender, args);
      }
   }
}
