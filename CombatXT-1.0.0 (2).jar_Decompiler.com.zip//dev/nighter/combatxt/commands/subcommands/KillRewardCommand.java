package dev.nighter.combatxt.commands.subcommands;

import dev.nighter.combatxt.CombatXT;
import dev.nighter.combatxt.commands.BaseCommand;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KillRewardCommand extends BaseCommand {
   public KillRewardCommand(CombatXT plugin) {
      super(plugin);
   }

   public boolean execute(CommandSender sender, String[] args) {
      if (!this.checkSender(sender)) {
         return true;
      } else if (args.length == 0) {
         this.sendUsage(sender);
         return true;
      } else {
         String subCommand = args[0];
         String[] subArgs = (String[])Arrays.copyOfRange(args, 1, args.length);
         byte var6 = -1;
         switch(subCommand.hashCode()) {
         case 94627080:
            if (subCommand.equals("check")) {
               var6 = 0;
            }
            break;
         case 94746189:
            if (subCommand.equals("clear")) {
               var6 = 1;
            }
            break;
         case 790268948:
            if (subCommand.equals("clearAll")) {
               var6 = 2;
            }
         }

         switch(var6) {
         case 0:
            return this.executeCheck(sender, subArgs);
         case 1:
            return this.executeClear(sender, subArgs);
         case 2:
            return this.executeClearAll(sender, subArgs);
         default:
            this.sendUsage(sender);
            return true;
         }
      }
   }

   private boolean executeCheck(CommandSender sender, String[] args) {
      Map<String, String> placeholders = new HashMap();
      if (args.length >= 1 && args.length <= 2) {
         Player killer = Bukkit.getPlayer(args[0]);
         if (killer == null) {
            placeholders.put("player", args[0]);
            this.messageService.sendMessage((CommandSender)sender, "player_not_found", placeholders);
            return true;
         } else {
            Player victim = null;
            if (args.length == 2) {
               victim = Bukkit.getPlayer(args[1]);
               if (victim == null) {
                  placeholders.put("player", args[1]);
                  this.messageService.sendMessage((CommandSender)sender, "player_not_found", placeholders);
                  return true;
               }
            }

            long remainingMs = this.plugin.getKillRewardManager().getRemainingCooldown(killer, victim);
            if (remainingMs <= 0L) {
               placeholders.put("player", killer.getName());
               if (victim != null) {
                  placeholders.put("target", victim.getName());
                  this.messageService.sendMessage((CommandSender)sender, "no_kill_cooldown_target", placeholders);
               } else {
                  this.messageService.sendMessage((CommandSender)sender, "no_kill_cooldown", placeholders);
               }
            } else {
               String formattedTime = this.formatTime(remainingMs);
               placeholders.put("player", killer.getName());
               placeholders.put("time", formattedTime);
               if (victim != null) {
                  placeholders.put("target", victim.getName());
                  this.messageService.sendMessage((CommandSender)sender, "kill_cooldown_remaining_target", placeholders);
               } else {
                  this.messageService.sendMessage((CommandSender)sender, "kill_cooldown_remaining", placeholders);
               }
            }

            return true;
         }
      } else {
         sender.sendMessage("§cUsage: /combatxt killReward check <player> [target_player]");
         return true;
      }
   }

   private boolean executeClear(CommandSender sender, String[] args) {
      Map<String, String> placeholders = new HashMap();
      if (args.length != 1) {
         sender.sendMessage("§cUsage: /combatxt killReward clear <player>");
         return true;
      } else {
         Player target = Bukkit.getPlayer(args[0]);
         if (target == null) {
            placeholders.put("player", args[0]);
            this.messageService.sendMessage((CommandSender)sender, "player_not_found", placeholders);
            return true;
         } else {
            this.plugin.getKillRewardManager().clearPlayerCooldowns(target);
            placeholders.put("player", target.getName());
            this.messageService.sendMessage((CommandSender)sender, "clear_cooldown_success", placeholders);
            return true;
         }
      }
   }

   private boolean executeClearAll(CommandSender sender, String[] args) {
      Map<String, String> placeholders = new HashMap();
      if (args.length != 0) {
         sender.sendMessage("§cUsage: /combatxt killReward clearAll");
         return true;
      } else {
         int cooldownCount = this.plugin.getKillRewardManager().getKillRewardCooldowns().size();
         if (cooldownCount == 0) {
            this.messageService.sendMessage((CommandSender)sender, "no_cooldowns_to_clear", placeholders);
            return true;
         } else {
            this.plugin.getKillRewardManager().getKillRewardCooldowns().clear();
            placeholders.put("count", String.valueOf(cooldownCount));
            this.messageService.sendMessage((CommandSender)sender, "clear_all_cooldowns_success", placeholders);
            return true;
         }
      }
   }

   private void sendUsage(CommandSender sender) {
      sender.sendMessage("§cUsage:");
      sender.sendMessage("§c/combatxt killReward check <player> [target_player]");
      sender.sendMessage("§c/combatxt killReward clear <player>");
      sender.sendMessage("§c/combatxt killReward clearAll");
   }

   private String formatTime(long milliseconds) {
      long days = TimeUnit.MILLISECONDS.toDays(milliseconds);
      long hours = TimeUnit.MILLISECONDS.toHours(milliseconds) % 24L;
      long minutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds) % 60L;
      long seconds = TimeUnit.MILLISECONDS.toSeconds(milliseconds) % 60L;
      StringBuilder sb = new StringBuilder();
      if (days > 0L) {
         sb.append(days).append("d ");
      }

      if (hours > 0L) {
         sb.append(hours).append("h ");
      }

      if (minutes > 0L) {
         sb.append(minutes).append("m ");
      }

      if (seconds > 0L) {
         sb.append(seconds).append("s");
      }

      return sb.length() > 0 ? sb.toString().trim() : "0s";
   }

   public String getPermission() {
      return "combatxt.command.use";
   }

   public boolean isPlayerOnly() {
      return false;
   }

   public List<String> tabComplete(CommandSender sender, String[] args) {
      if (args.length == 1) {
         return (List)Arrays.asList("check", "clear", "clearAll").stream().filter((cmd) -> {
            return cmd.toLowerCase().startsWith(args[0].toLowerCase());
         }).collect(Collectors.toList());
      } else {
         if (args.length >= 2) {
            String subCommand = args[0].toLowerCase();
            byte var5 = -1;
            switch(subCommand.hashCode()) {
            case 94627080:
               if (subCommand.equals("check")) {
                  var5 = 0;
               }
               break;
            case 94746189:
               if (subCommand.equals("clear")) {
                  var5 = 1;
               }
               break;
            case 790268948:
               if (subCommand.equals("clearAll")) {
                  var5 = 2;
               }
            }

            switch(var5) {
            case 0:
               if (args.length != 2 && args.length != 3) {
                  break;
               }

               return (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).filter((name) -> {
                  return name.toLowerCase().startsWith(args[args.length - 1].toLowerCase());
               }).collect(Collectors.toList());
            case 1:
               if (args.length == 2) {
                  return (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).filter((name) -> {
                     return name.toLowerCase().startsWith(args[1].toLowerCase());
                  }).collect(Collectors.toList());
               }
            case 2:
            }
         }

         return super.tabComplete(sender, args);
      }
   }
}
