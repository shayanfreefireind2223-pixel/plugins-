package dev.nighter.combatxt.commands.subcommands;

import dev.nighter.combatxt.CombatXT;
import dev.nighter.combatxt.commands.BaseCommand;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TagCommand extends BaseCommand {
   public TagCommand(CombatXT plugin) {
      super(plugin);
   }

   public boolean execute(CommandSender sender, String[] args) {
      if (!this.checkSender(sender)) {
         return true;
      } else {
         Map<String, String> placeholders = new HashMap();
         if (args.length >= 1 && args.length <= 2) {
            Player player1 = Bukkit.getPlayer(args[0]);
            if (player1 == null) {
               placeholders.put("player", args[0]);
               this.messageService.sendMessage((CommandSender)sender, "player_not_found", placeholders);
               return true;
            } else {
               if (args.length == 1) {
                  this.plugin.getCombatManager().updateMutualCombat(player1, player1);
                  placeholders.put("player", player1.getName());
                  this.messageService.sendMessage((CommandSender)sender, "combat_tag_single_success", placeholders);
               } else {
                  Player player2 = Bukkit.getPlayer(args[1]);
                  if (player2 == null) {
                     placeholders.put("player", args[1]);
                     this.messageService.sendMessage((CommandSender)sender, "player_not_found", placeholders);
                     return true;
                  }

                  this.plugin.getCombatManager().updateMutualCombat(player1, player2);
                  placeholders.put("player1", player1.getName());
                  placeholders.put("player2", player2.getName());
                  this.messageService.sendMessage((CommandSender)sender, "combat_tag_success", placeholders);
               }

               return true;
            }
         } else {
            sender.sendMessage("§cUsage: /combatxt tag <player1> [player2]");
            return true;
         }
      }
   }

   public String getPermission() {
      return "combatxt.command.use";
   }

   public boolean isPlayerOnly() {
      return false;
   }

   public List<String> tabComplete(CommandSender sender, String[] args) {
      return args.length != 1 && args.length != 2 ? super.tabComplete(sender, args) : (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).filter((name) -> {
         return name.toLowerCase().startsWith(args[args.length - 1].toLowerCase());
      }).collect(Collectors.toList());
   }
}
