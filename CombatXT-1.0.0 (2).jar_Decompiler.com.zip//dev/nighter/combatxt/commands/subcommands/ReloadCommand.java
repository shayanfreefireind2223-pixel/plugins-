package dev.nighter.combatxt.commands.subcommands;

import dev.nighter.combatxt.CombatXT;
import dev.nighter.combatxt.commands.BaseCommand;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.command.CommandSender;

public class ReloadCommand extends BaseCommand {
   public ReloadCommand(CombatXT plugin) {
      super(plugin);
   }

   public boolean execute(CommandSender sender, String[] args) {
      if (!this.checkSender(sender)) {
         return true;
      } else {
         Map<String, String> placeholders = new HashMap();
         this.plugin.reload();
         this.plugin.reloadConfig();
         this.plugin.getLanguageManager().reloadLanguages();
         this.plugin.refreshTimeCache();
         if (this.plugin.getWorldGuardHook() != null) {
            this.plugin.getWorldGuardHook().reloadConfig();
         }

         if (this.plugin.getGriefPreventionHook() != null) {
            this.plugin.getGriefPreventionHook().reloadConfig();
         }

         this.plugin.getCombatManager().reloadConfig();
         this.plugin.getKillRewardManager().loadConfig();
         this.plugin.getNewbieProtectionManager().reloadConfig();
         this.plugin.getCombatListeners().reload();
         this.messageService.sendMessage((CommandSender)sender, "config_reloaded", placeholders);
         return true;
      }
   }

   public String getPermission() {
      return "combatxt.command.use";
   }

   public boolean isPlayerOnly() {
      return false;
   }

   public List<String> tabComplete(CommandSender sender, String[] args) {
      return new ArrayList();
   }
}
