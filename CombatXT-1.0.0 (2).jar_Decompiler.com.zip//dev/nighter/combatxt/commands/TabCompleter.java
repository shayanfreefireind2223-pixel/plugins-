package dev.nighter.combatxt.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public class TabCompleter implements org.bukkit.command.TabCompleter {
   private final CommandManager commandManager;

   public TabCompleter(CommandManager commandManager) {
      this.commandManager = commandManager;
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (args.length == 1) {
         return (List)this.commandManager.getCommands().entrySet().stream().filter((entry) -> {
            return ((BaseCommand)entry.getValue()).hasPermission(sender);
         }).map((entry) -> {
            return (String)entry.getKey();
         }).filter((cmd) -> {
            return cmd.toLowerCase().startsWith(args[0].toLowerCase());
         }).collect(Collectors.toList());
      } else {
         if (args.length > 1) {
            String subCommand = args[0];
            BaseCommand baseCommand = (BaseCommand)this.commandManager.getCommands().get(subCommand);
            if (baseCommand == null) {
               baseCommand = (BaseCommand)this.commandManager.getCommands().entrySet().stream().filter((entry) -> {
                  return ((String)entry.getKey()).equalsIgnoreCase(subCommand);
               }).map((entry) -> {
                  return (BaseCommand)entry.getValue();
               }).findFirst().orElse((Object)null);
            }

            if (baseCommand != null && baseCommand.hasPermission(sender)) {
               String[] subArgs = new String[args.length - 1];
               System.arraycopy(args, 1, subArgs, 0, args.length - 1);
               return baseCommand.tabComplete(sender, subArgs);
            }
         }

         return new ArrayList();
      }
   }
}
