package dev.nighter.combatxt.commands;

import dev.nighter.combatxt.CombatXT;
import dev.nighter.combatxt.language.MessageService;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public abstract class BaseCommand {
   protected final CombatXT plugin;
   protected final MessageService messageService;

   public BaseCommand(CombatXT plugin) {
      this.plugin = plugin;
      this.messageService = plugin.getMessageService();
   }

   public abstract boolean execute(CommandSender var1, String[] var2);

   public abstract String getPermission();

   public boolean hasPermission(CommandSender sender) {
      return sender.hasPermission(this.getPermission());
   }

   public abstract boolean isPlayerOnly();

   public List<String> tabComplete(CommandSender sender, String[] args) {
      return Collections.emptyList();
   }

   protected boolean checkSender(CommandSender sender) {
      HashMap placeholders;
      if (this.isPlayerOnly() && !(sender instanceof Player)) {
         placeholders = new HashMap();
         this.messageService.sendMessage((CommandSender)sender, "error_player_only", placeholders);
         return false;
      } else if (!this.hasPermission(sender)) {
         placeholders = new HashMap();
         placeholders.put("permission", this.getPermission());
         this.messageService.sendMessage((CommandSender)sender, "no_permission", placeholders);
         return false;
      } else {
         return true;
      }
   }
}
